pipeline {
  agent any
  stages {
    stage('one') { steps { echo 'bench-mark-line' } }
  }
}
