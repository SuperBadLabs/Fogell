#!/usr/bin/env bash
# Run every solution test project, independent of directory depth or filename.
# The caller must build first; this runner deliberately uses --no-build so a
# test execution cannot hide an inventory or configuration error behind a
# second implicit build.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
LOG_DIR=""

if [ "${1:-}" = "--log-dir" ]; then
  [ "$#" -eq 2 ] || { echo "usage: $0 [--log-dir DIR]" >&2; exit 2; }
  LOG_DIR="$2"
elif [ "$#" -ne 0 ]; then
  echo "usage: $0 [--log-dir DIR]" >&2
  exit 2
fi

if [ -n "$LOG_DIR" ]; then
  mkdir -p -- "$LOG_DIR"
  LOG_DIR="$(cd "$LOG_DIR" && pwd -P)"
fi

scratch="$(mktemp -d /tmp/fogell-project-tests.XXXXXX)"
trap 'rm -rf -- "$scratch"' EXIT

test_projects=()
mapfile -d '' test_projects < <(
  python3 - "$ROOT/Fogell.slnx" <<'PYTHON'
import sys, xml.etree.ElementTree as ET
projects = [p.attrib['Path'] for p in ET.parse(sys.argv[1]).iter('Project')
            if p.attrib['Path'].startswith('tests/')]
if not projects or len(projects) != len(set(projects)):
    raise SystemExit('invalid test project inventory')
for project in projects:
    sys.stdout.buffer.write(project.encode() + b'\0')
PYTHON
)
inventory_pid=$!
if ! wait "$inventory_pid"; then
  echo "solution test project inventory could not be read" >&2
  exit 1
fi
[ "${#test_projects[@]}" -gt 0 ] || {
  echo "no test projects were discovered" >&2
  exit 1
}

for project in "${test_projects[@]}"; do
  full_log="$(mktemp "$scratch/test.XXXXXX")"
  test_rc=0
  (
    cd "$ROOT"
    dotnet run --project "$project" -c Release --no-build
  ) >"$full_log" 2>&1 || test_rc=$?

  if [ "$test_rc" -ne 0 ]; then
    cat "$full_log" >&2
    echo "test project failed: $project" >&2
    exit 1
  fi

  normalized_log="$(mktemp "$scratch/normalized.XXXXXX")"
  # Expecto can retain ANSI colour and its timestamp/logger envelope even when
  # redirected (HeMan does). Remove terminal decoration, then count summary
  # MARKERS rather than lines: a failure and a forged success on one physical
  # line are still two summaries and must refuse.
  #
  # Every text tool on this boundary is pinned to LC_ALL=C: the bracket ranges
  # in this strip collate by locale, and under a collating UTF-8 locale
  # (en_US.UTF-8, GNU sed 4.9) they match nothing, escapes survive, and the
  # summary check below refuses genuine successes. C also makes the tools
  # byte-oriented, so raw test output that is not valid UTF-8 cannot make a
  # pattern silently stop matching. Only these tool invocations are pinned —
  # the test processes themselves keep the caller's locale.
  LC_ALL=C sed $'s/\033\\[[0-9;?]*[ -\\/]*[@-~]//g' "$full_log" >"$normalized_log"
  summary_markers="$(
    LC_ALL=C awk '
      {
        rest = $0
        while ((position = index(rest, "EXPECTO! ")) != 0) {
          count++
          rest = substr(rest, position + 9)
        }
      }
      END { print count + 0 }
    ' "$normalized_log"
  )"
  if [ "$summary_markers" -eq 0 ]; then
    cat "$full_log" >&2
    echo "test project produced no Expecto summary: $project" >&2
    exit 1
  fi
  if [ "$summary_markers" -ne 1 ]; then
    cat "$full_log" >&2
    echo "test project produced multiple Expecto summaries: $project" >&2
    exit 1
  fi

  summaries=()
  # One marker exists. Extract its semantic summary through Expecto's explicit
  # terminator; a marker without a well-formed terminator is a non-success below.
  mapfile -t summaries < <(
    LC_ALL=C sed -E -n 's/^.*(EXPECTO! .*(Success|Failure)!).*$/\1/p' "$normalized_log"
  )
  summary="${summaries[0]:-}"
  # Digits are enumerated rather than written as ranges: [[ =~ ]] cannot be
  # locale-pinned per invocation, and a range expression collates by the
  # ambient locale. An enumerated bracket expression has no collation at all.
  summary_pattern='^EXPECTO! ([0123456789]{1,9}) tests? run .* ([0123456789]{1,9}) passed, ([0123456789]{1,9}) ignored, ([0123456789]{1,9}) failed, ([0123456789]{1,9}) errored\. Success!$'
  summary_valid=false
  if [[ "$summary" =~ $summary_pattern ]]; then
    total=$((10#${BASH_REMATCH[1]}))
    passed=$((10#${BASH_REMATCH[2]}))
    ignored=$((10#${BASH_REMATCH[3]}))
    failed=$((10#${BASH_REMATCH[4]}))
    errored=$((10#${BASH_REMATCH[5]}))
    if [ "$total" -gt 0 ] \
      && [ "$failed" -eq 0 ] \
      && [ "$errored" -eq 0 ] \
      && [ "$total" -eq $((passed + ignored + failed + errored)) ]; then
      summary_valid=true
    fi
  fi
  if [ "$summary_valid" != true ]; then
    cat "$full_log" >&2
    echo "test project produced a non-success Expecto summary: $project" >&2
    exit 1
  fi

  printf '%q: %s\n' "$project" "$summary"
  if [ -n "$LOG_DIR" ]; then
    project_key="$(printf '%s' "$project" | sha256sum | cut -c1-16)"
    {
      # Paths are Git/NUL-safe and can contain newlines. Shell escaping keeps
      # each value on one line and is reversible with a standard shell parser;
      # raw `%s` would let a path forge additional evidence-log fields.
      printf 'project: %q\n' "$project"
      printf 'working-directory: %q\n' "$ROOT"
      printf '%s\n' "$summary"
    } >"$LOG_DIR/tests-$project_key.log"
  fi
done
