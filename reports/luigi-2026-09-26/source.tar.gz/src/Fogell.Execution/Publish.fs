namespace Fogell.Execution

open System
open System.Collections.Generic
open System.IO
open System.Security.Cryptography
open System.Text
open System.Threading
open System.Text.RegularExpressions

type ArtifactStore =
    { Root: string
      Limits: ArtifactLimits }

    static member under(root: string) =
        { Root = root
          Limits = ArtifactLimits.Defaults }

    static member underWithLimits(root: string) (limits: ArtifactLimits) =
        { Root = root
          Limits = limits }

    static member withLimits(limits: ArtifactLimits) (store: ArtifactStore) =
        { store with Limits = limits }

type JUnitProblem =
    | Interrupted
    | NoReports
    | MissingTestName of report: string
    | MissingIdentity
    | Unreadable of string

module JUnitDiagnostics =

    [<Literal>]
    let MissingTestNameMessage =
        "Test report case is missing a name"

type StashStore =
    { Root: string }

    static member under (root: string) = { Root = root }

module Publish =

    type private DiagnosticCallbackException(inner: exn) =
        inherit Exception("diagnostic callback failed", inner)

    type private MissingJUnitTestNameException() =
        inherit IOException("JUnit testcase has no name attribute or class fallback")

    type private OldJUnitReportException() =
        inherit IOException("JUnit report predates the build timestamp boundary")

    type private EmptyJUnitReportException() =
        inherit IOException("JUnit report is empty")

    let private compileGlobRegex (caseSensitive: bool) (pattern: string) =
        let normalised = pattern.Replace('\\', '/').Trim()

        let escaped =
            normalised.Split('/')
            |> Array.map (fun segment ->
                if segment = "**" then
                    "(?:.*)"
                else
                    segment
                    |> Regex.Escape
                    |> fun e -> e.Replace(@"\*", "[^/]*").Replace(@"\?", "[^/]"))
            |> String.concat "/"
            // `**/x` must also match a bare `x` at the root
            |> fun p -> p.Replace("(?:.*)/", "(?:.*/)?")

        let options =
            if caseSensitive then RegexOptions.None
            else RegexOptions.IgnoreCase ||| RegexOptions.CultureInvariant

        Regex("^" + escaped + "$", options)

    // Ant 1.10.17 DirectoryScanner.DEFAULTEXCLUDES. JUnit creates a FileSet and
    // leaves useDefaultExcludes at its true default; stash does the same unless
    // its public flag is explicitly false. These exclusions therefore remain
    // active even when an include names one of the paths literally. The pinned
    // list is case-sensitive and shared only by those two Ant-backed selectors;
    // archive retains its established matcher and behavior.
    let internal antDefaultExcludePatterns =
        [ "**/*~"
          "**/#*#"
          "**/.#*"
          "**/%*%"
          "**/._*"
          "**/CVS"
          "**/CVS/**"
          "**/.cvsignore"
          "**/SCCS"
          "**/SCCS/**"
          "**/vssver.scc"
          "**/.svn"
          "**/.svn/**"
          "**/.git"
          "**/.git/**"
          "**/.gitattributes"
          "**/.gitignore"
          "**/.gitmodules"
          "**/.hg"
          "**/.hg/**"
          "**/.hgignore"
          "**/.hgsub"
          "**/.hgsubstate"
          "**/.hgtags"
          "**/.bzr"
          "**/.bzr/**"
          "**/.bzrignore"
          "**/.DS_Store" ]

    let private antDefaultExcludeRegexes =
        antDefaultExcludePatterns |> List.map (compileGlobRegex true)

    let internal isAntDefaultExcluded (relative: string) =
        antDefaultExcludeRegexes |> List.exists (fun regex -> regex.IsMatch relative)

    let internal compileGlobMatcher (caseSensitive: bool) (pattern: string) =
        let regex = compileGlobRegex caseSensitive pattern
        fun (relative: string) -> regex.IsMatch relative

    let private expandGlobWithCase (caseSensitive: bool) (workspace: string) (pattern: string) : string list =
        if not (Directory.Exists workspace) then
            []
        else
            let regex = compileGlobRegex caseSensitive pattern

            Directory.GetFiles(workspace, "*", SearchOption.AllDirectories)
            |> Array.choose (fun full ->
                let relative = Path.GetRelativePath(workspace, full).Replace('\\', '/')
                if regex.IsMatch relative then Some relative else None)
            |> Array.sort
            |> Array.toList

    let expandGlob workspace pattern = expandGlobWithCase false workspace pattern

    // Ant tokenizes include patterns by path component and discards empty tokens,
    // so repeated separators inside a JUnit include are equivalent to one. It also
    // appends `**` when an include ends in a separator. For wildcard-bearing
    // prefixes, the suffix-free arm below represents terminal `**` consuming zero
    // components (for example `reports/*/` also selects `reports/result.xml`);
    // the suffixed arm selects descendants. A wholly literal prefix stays a
    // directory lookup: Ant does not reinterpret a literal `report.xml/` as the
    // file `report.xml`.
    // Keep both rules private to JUnit: archive/stash retain their shared matcher.
    // Collapsing instead of removing separators preserves rooted patterns as rooted.
    let private normalizeJUnitPatterns (pattern: string) =
        let normalized =
            pattern.Replace('\\', '/')
            |> fun value -> Regex.Replace(value, "/+", "/")

        if normalized.EndsWith("/", StringComparison.Ordinal) then
            let prefix = normalized.Substring(0, normalized.Length - 1)

            if prefix.Contains('*') || prefix.Contains('?') then
                [ prefix; normalized + "**" ]
            else
                [ normalized + "**" ]
        else
            [ normalized ]

    type private JUnitPatternSpec =
        { Matcher: Regex
          IsLiteral: bool
          LiteralPrefix: string
          IsRooted: bool }

    type private JUnitFileCandidate =
        { Relative: string
          PhysicalPath: string }

    type private JUnitSelectedCandidate =
        { Relative: string
          PhysicalTarget: string option }

    let private compileJUnitPatternSpec (normalized: string) =
        let prefix =
            normalized.Split('/', StringSplitOptions.RemoveEmptyEntries)
            |> Array.takeWhile (fun segment -> not (segment.Contains('*') || segment.Contains('?')))
            |> String.concat "/"

        { Matcher = compileGlobRegex true normalized
          IsLiteral = not (normalized.Contains('*') || normalized.Contains('?'))
          LiteralPrefix = prefix
          IsRooted = Path.IsPathRooted normalized }

    // This is deliberately conservative after the first wildcard: it may walk
    // extra descendants under the literal prefix, but never an unrelated top-
    // level tree for a narrow include. The shared work budget bounds that extra.
    let private junitPatternMayMatchDescendant (spec: JUnitPatternSpec) logicalDirectory =
        if spec.IsRooted then
            false
        elif String.IsNullOrEmpty spec.LiteralPrefix || String.IsNullOrEmpty logicalDirectory then
            true
        else
            spec.LiteralPrefix = logicalDirectory
            || spec.LiteralPrefix.StartsWith(logicalDirectory + "/", StringComparison.Ordinal)
            || logicalDirectory.StartsWith(spec.LiteralPrefix + "/", StringComparison.Ordinal)

    let private junitScanLimit = 100_000

    // Ant DirectoryScanner follows healthy links by their logical scanner path,
    // including directory links whose target is outside the FileSet base. Its
    // cycle guard is not a global symlink-depth limit: it prunes a branch only
    // after the same canonical directory target has been followed five times.
    // Enumerate JUnit inputs privately so archive/stash keep their established
    // matcher. The explicit stack, cancellation polling, pattern pruning, and a
    // hard logical-entry ceiling bound CPU, memory, and queue growth.
    let private enumerateJUnitFiles
        (scanLimit: int)
        (workspace: string)
        (specs: JUnitPatternSpec list)
        (workUnits: int ref)
        (abort: unit -> bool)
        : Result<JUnitFileCandidate list, JUnitProblem> =
        if not (Directory.Exists workspace) then
            Ok []
        else
            let files = System.Collections.Generic.List<JUnitFileCandidate>()
            let pending =
                System.Collections.Generic.Stack<string * string * Map<string, int> * bool>()
            let mutable problem: JUnitProblem option = None

            let chargeWork () =
                if workUnits.Value >= scanLimit then
                    problem <-
                        Some(
                            Unreadable(
                                $"JUnit report scan exceeded the {scanLimit} logical-entry safety limit"))
                    false
                else
                    workUnits.Value <- workUnits.Value + 1
                    true

            let anySpec (predicate: JUnitPatternSpec -> bool) =
                let mutable matched = false
                use enumerator = (specs :> seq<JUnitPatternSpec>).GetEnumerator()

                while Option.isNone problem && not matched && enumerator.MoveNext() do
                    if chargeWork () then
                        matched <- predicate enumerator.Current

                matched

            pending.Push(workspace, "", Map.empty, false)

            try
                while pending.Count > 0 && Option.isNone problem do
                    if abort () then
                        problem <- Some Interrupted
                    else
                        let physicalDirectory, logicalDirectory, followedTargets, missingAllowed = pending.Pop()

                        try
                            use entries = DirectoryInfo(physicalDirectory).EnumerateFileSystemInfos().GetEnumerator()

                            while Option.isNone problem && entries.MoveNext() do
                                if abort () then
                                    problem <- Some Interrupted
                                elif chargeWork () then
                                    let entry = entries.Current
                                    let logical =
                                        if logicalDirectory = "" then entry.Name
                                        else logicalDirectory + "/" + entry.Name

                                    let excluded = isAntDefaultExcluded logical
                                    let selectFile =
                                        not excluded && anySpec (fun spec -> spec.Matcher.IsMatch logical)
                                    let descend =
                                        not excluded
                                        && anySpec (fun spec -> junitPatternMayMatchDescendant spec logical)

                                    // Do not even resolve a symlink whose logical
                                    // path cannot contribute to an include.
                                    if selectFile || descend then
                                        let isLink = not (isNull entry.LinkTarget)

                                        if isLink then
                                            try
                                                let directTarget =
                                                    if Path.IsPathRooted entry.LinkTarget then entry.LinkTarget
                                                    else Path.Combine(Path.GetDirectoryName entry.FullName, entry.LinkTarget)

                                                let isDirectSelfLoop =
                                                    String.Equals(
                                                        Path.GetFullPath directTarget,
                                                        Path.GetFullPath entry.FullName,
                                                        StringComparison.Ordinal)

                                                if isDirectSelfLoop then
                                                    if selectFile then
                                                        files.Add
                                                            { Relative = logical
                                                              PhysicalPath = entry.FullName }
                                                else
                                                    let target = entry.ResolveLinkTarget(true)

                                                    if not (isNull target) then
                                                        if
                                                            target :? DirectoryInfo
                                                            || (descend && not selectFile && not target.Exists)
                                                        then
                                                            if descend then
                                                                let canonicalTarget = Path.GetFullPath target.FullName
                                                                let followed =
                                                                    followedTargets
                                                                    |> Map.tryFind canonicalTarget
                                                                    |> Option.defaultValue 0

                                                                if followed < 5 then
                                                                    pending.Push(
                                                                        target.FullName,
                                                                        logical,
                                                                        followedTargets
                                                                        |> Map.add canonicalTarget (followed + 1),
                                                                        true)
                                                        elif selectFile then
                                                            files.Add
                                                                { Relative = logical
                                                                  PhysicalPath = entry.FullName }
                                            with
                                            | :? FileNotFoundException
                                            | :? DirectoryNotFoundException ->
                                                // A wildcard-selected file link
                                                // that vanishes during resolution
                                                // remains a lexical synthetic
                                                // candidate. Literal selection is
                                                // filtered by its later open probe.
                                                if selectFile then
                                                    files.Add
                                                        { Relative = logical
                                                          PhysicalPath = entry.FullName }
                                            | ex ->
                                                problem <-
                                                    Some(
                                                        Unreadable(
                                                            $"JUnit report scan failed: {logical}: {ex.GetType().Name}"))
                                        elif entry :? DirectoryInfo then
                                            if descend then
                                                pending.Push(entry.FullName, logical, followedTargets, false)
                                        elif selectFile then
                                            // Wildcard scans retain dangling file
                                            // links lexically; the literal fast
                                            // path filters them after resolution.
                                            files.Add
                                                { Relative = logical
                                                  PhysicalPath = entry.FullName }
                        with
                        | (:? FileNotFoundException | :? DirectoryNotFoundException)
                            when missingAllowed -> ()
                        | ex ->
                            problem <-
                                Some(
                                    Unreadable(
                                        $"JUnit report scan failed: {logicalDirectory}: {ex.GetType().Name}"))

                match problem with
                | Some failure -> Error failure
                | None -> Ok(files |> Seq.sort |> Seq.toList)
            with ex ->
                match problem with
                | Some Interrupted -> Error Interrupted
                | Some failure -> Error failure
                | None -> Error(Unreadable($"JUnit report scan failed: {ex.GetType().Name}"))

    type private JUnitTargetResolution =
        | TargetMissing
        | TargetFound of FileInfo
        | TargetUnreadable of exn

    let private junitFileTargetInfo (fullPath: string) =
        let candidate = FileInfo fullPath

        try
            let linkTarget = candidate.LinkTarget

            if isNull linkTarget then
                candidate.Refresh()
                if candidate.Exists then TargetFound candidate else TargetMissing
            else
                let directTarget =
                    if Path.IsPathRooted linkTarget then linkTarget
                    else Path.Combine(candidate.DirectoryName, linkTarget)

                // The measured file self-loop is absence in java.io.File terms.
                // Recognise only that exact loop; other resolver/I/O failures
                // must remain distinguishable from a dangling target.
                if
                    String.Equals(
                        Path.GetFullPath directTarget,
                        Path.GetFullPath candidate.FullName,
                        StringComparison.Ordinal)
                then
                    TargetMissing
                else
                    match candidate.ResolveLinkTarget(true) with
                    | null -> TargetMissing
                    | target ->
                        let targetInfo = FileInfo target.FullName
                        targetInfo.Refresh()
                        // ResolveLinkTarget returns a physical path even when its
                        // final target is absent. Preserve that path so an open can
                        // distinguish FileNotFound from authority and other I/O.
                        TargetFound targetInfo
        with
        | :? FileNotFoundException
        | :? DirectoryNotFoundException -> TargetMissing
        | ex -> TargetUnreadable ex

    let private expandJUnitGlobs
        (scanLimit: int)
        (workspace: string)
        (patterns: string list)
        (abort: unit -> bool) =
        let rawPatternWork =
            patterns
            |> List.fold (fun total pattern ->
                min (scanLimit + 1) (total + pattern.Length + 1)) 0

        let patternLimitExceeded = rawPatternWork > scanLimit
        let normalized =
            if patternLimitExceeded then []
            else patterns |> List.collect normalizeJUnitPatterns
        let specs = normalized |> List.map compileJUnitPatternSpec
        let workUnits = ref rawPatternWork
        let scanResult = enumerateJUnitFiles scanLimit workspace specs workUnits abort

        match patternLimitExceeded, scanResult with
        | true, _ ->
            Error(
                Unreadable(
                    $"JUnit report scan exceeded the {scanLimit} logical-entry safety limit"))
        | false, Error problem -> Error problem
        | false, Ok files ->
            let selected = System.Collections.Generic.List<JUnitSelectedCandidate>()
            let mutable problem: JUnitProblem option = None
            use patternEnumerator = (specs :> seq<JUnitPatternSpec>).GetEnumerator()

            while Option.isNone problem && patternEnumerator.MoveNext() do
                let spec = patternEnumerator.Current
                use candidates = (files :> seq<JUnitFileCandidate>).GetEnumerator()

                while Option.isNone problem && candidates.MoveNext() do
                  if abort () then
                    problem <- Some Interrupted
                  elif workUnits.Value >= scanLimit then
                    problem <-
                        Some(
                            Unreadable(
                                $"JUnit report scan exceeded the {scanLimit} logical-entry safety limit"))
                  else
                    workUnits.Value <- workUnits.Value + 1
                    let candidate = candidates.Current

                    if spec.Matcher.IsMatch candidate.Relative then
                      // Resolve a final file link exactly once during selection.
                      // The stored physical target survives a later retarget of
                      // either the file link or an ancestor directory link.
                      match junitFileTargetInfo candidate.PhysicalPath with
                        | TargetFound targetInfo ->
                            if spec.IsLiteral then
                                try
                                    use probe =
                                        new FileStream(
                                            targetInfo.FullName,
                                            FileMode.Open,
                                            FileAccess.Read,
                                            FileShare.ReadWrite ||| FileShare.Delete)
                                    selected.Add
                                        { Relative = candidate.Relative
                                          PhysicalTarget = Some targetInfo.FullName }
                                with
                                | :? FileNotFoundException
                                | :? DirectoryNotFoundException -> ()
                                | ex ->
                                    problem <-
                                        Some(
                                            Unreadable(
                                                $"unparsable test report(s): {candidate.Relative}: {ex.GetType().Name}"))
                            else
                                selected.Add
                                    { Relative = candidate.Relative
                                      PhysicalTarget = Some targetInfo.FullName }
                        | TargetMissing ->
                            if not spec.IsLiteral then
                                selected.Add
                                    { Relative = candidate.Relative
                                      PhysicalTarget = None }
                        | TargetUnreadable ex ->
                            problem <-
                                Some(
                                    Unreadable(
                                        $"unparsable test report(s): {candidate.Relative}: {ex.GetType().Name}"))

            match problem with
            | Some failure -> Error failure
            | None ->
                Ok(
                    selected
                    |> Seq.distinctBy (fun candidate -> candidate.Relative)
                    |> Seq.sortBy (fun candidate -> candidate.Relative)
                    |> Seq.toList)

    let private artifactFailure () = IOException("Artifact publication failed.")

    let private strictRelativePath (value: string) =
        let segments = value.Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
        let reserved =
            [ ".fogell-artifact-pending"
              ".fogell-artifact-locks"
              ".fogell-artifact-history" ]

        not (String.IsNullOrWhiteSpace value)
        && not (Path.IsPathFullyQualified value)
        && (segments
            |> Array.forall (fun segment -> not (String.IsNullOrEmpty segment) && segment <> "." && segment <> ".."))
        && not (reserved |> List.contains segments.[0])

    let private artifactBuildId (buildKey: string) =
        SHA256.HashData(Encoding.UTF8.GetBytes buildKey)
        |> Convert.ToHexString
        |> fun value -> value.ToLowerInvariant()

    let private artifactTarget (store: ArtifactStore) (buildKey: string) =
        if not (strictRelativePath buildKey) then
            raise (artifactFailure ())

        let root = Path.GetFullPath store.Root
        let target = Path.GetFullPath(Path.Combine(root, buildKey))
        let prefix = root.TrimEnd(Path.DirectorySeparatorChar) + string Path.DirectorySeparatorChar

        if not (target.StartsWith(prefix, StringComparison.Ordinal)) then
            raise (artifactFailure ())

        target

    let private artifactSidecar (store: ArtifactStore) (buildKey: string) =
        let root = Path.GetFullPath store.Root
        let id = artifactBuildId buildKey
        let relative = Path.Combine(".fogell-artifact-pending", id)
        let lockRelative = Path.Combine(".fogell-artifact-locks", id + ".lock")
        relative, Path.Combine(root, relative), lockRelative, Path.Combine(root, lockRelative)

    let private requireUnlinkedArtifactTarget (target: string) =
        match Native.openDirectoryIfPresentWithoutLinks target with
        | Ok(Some handle) -> handle.Dispose()
        | Ok None -> ()
        | Error _ -> raise (artifactFailure ())

    let private validateArtifactLimits (limits: ArtifactLimits) =
        if
            limits.MaxFileBytes < 0L
            || limits.MaxTotalBytes < 0L
            || limits.MaxFiles < 0
            || limits.MaxScanEntries < 0
        then
            invalidArg "limits" "Artifact limits must be non-negative."

    type private HeldArtifactLock(gate: Mutex, stream: FileStream) =
        interface IDisposable with
            member _.Dispose() =
                try
                    Native.releaseExclusiveFileLock stream
                finally
                    try
                        stream.Dispose()
                    finally
                        try
                            gate.ReleaseMutex()
                        finally
                            gate.Dispose()

    /// The named kernel mutex has no process-local build dictionary to leak,
    /// while still serializing parallel calls in this process and writers in
    /// other processes. Its name is derived from a lock identity outside the
    /// frozen snapshot directory. Polling WaitOne(0) keeps an archive deadline
    /// observable while another worker owns the build.
    let internal acquireArtifactLockUsing
        (tryAcquire: FileStream -> bool)
        (storeRoot: string)
        (lockRelative: string)
        (lockPath: string)
        (abort: unit -> bool)
        (nonBlocking: bool)
        =
        let name = "fogell-artifact-" + artifactBuildId lockPath
        let gate = new Mutex(false, name)
        let stream =
            match Native.openOrCreateFileWithoutLinks storeRoot lockRelative with
            | Ok stream -> stream
            | Error _ ->
                gate.Dispose()
                raise (artifactFailure ())
        let mutable acquired = false
        let mutable cancelled = false
        let mutable ownsGate = false

        try
            while not acquired && not cancelled do
                ownsGate <- false

                try
                    ownsGate <- gate.WaitOne 0
                with :? AbandonedMutexException ->
                    ownsGate <- true

                if ownsGate then
                    if tryAcquire stream then
                        acquired <- true
                    else
                        gate.ReleaseMutex()
                        ownsGate <- false

                if not acquired then
                    if nonBlocking then
                        cancelled <- true
                    elif abort () then
                        cancelled <- true
                    else
                        Thread.Sleep 20

            if acquired then Some(new HeldArtifactLock(gate, stream) :> IDisposable)
            else
                stream.Dispose()
                gate.Dispose()
                None
        with _ ->
            // Closing a named mutex handle does not release ownership while
            // another caller still has it open. An acquisition I/O failure
            // must release the gate before propagating to keep waiters live.
            try
                if ownsGate then gate.ReleaseMutex()
            finally
                try stream.Dispose()
                finally gate.Dispose()
            reraise ()

    let private acquireArtifactLock =
        acquireArtifactLockUsing Native.tryAcquireExclusiveFileLock

    let private removePendingFiles
        (store: ArtifactStore)
        (pendingRelative: string)
        (pending: string)
        (scanLimit: int)
        (abort: unit -> bool)
        =
        match Native.openDirectoryIfPresentWithoutLinks pending with
        | Ok None -> true
        | Error _ -> false
        | Ok(Some descriptor) ->
            use descriptor = descriptor
            let mutable entries = 0
            let mutable complete = true

            try
                use files =
                    DirectoryInfo(Native.directoryDescriptorPath descriptor)
                        .EnumerateFileSystemInfos()
                        .GetEnumerator()

                while complete && files.MoveNext() do
                    if abort () || entries >= scanLimit then
                        complete <- false
                    else
                        entries <- entries + 1
                        let entry = files.Current

                        if
                            entry :? DirectoryInfo
                            || entry.Attributes.HasFlag FileAttributes.ReparsePoint
                            || not (entry.Name.EndsWith(".part", StringComparison.Ordinal))
                        then
                            complete <- false
                        else
                            let relative = Path.Combine(pendingRelative, entry.Name)

                            match Native.deleteFileWithoutLinks store.Root relative with
                            | Ok() -> ()
                            | Error _ -> complete <- false

                complete
            with :? IOException -> false
                 | :? UnauthorizedAccessException -> false

    /// Remove stale, unpublished staging files for one build.  It never waits
    /// on a writer; callers which need cleanup during controller finalization
    /// can retry after a false return.
    let cleanupPending (store: ArtifactStore) (buildKey: string) (abort: unit -> bool) =
        validateArtifactLimits store.Limits
        if not (strictRelativePath buildKey) then
            false
        else
            // Validate the key's target shape without opening the staging
            // directory. A concurrent snapshot finalizer may move that target;
            // sidecar cleanup has its own descriptor-anchored custody checks.
            artifactTarget store buildKey |> ignore
            let pendingRelative, pending, lockRelative, lockPath = artifactSidecar store buildKey

            let rec tryCleanup remaining =
                // Finalizers often race after another one has already cleaned this
                // sidecar. The absence fast path makes that case idempotent without
                // acquiring a kernel mutex.
                match Native.openDirectoryIfPresentWithoutLinks pending with
                | Ok None -> true
                | Error _ -> false
                | Ok(Some probe) ->
                    use probe = probe
                    match acquireArtifactLock store.Root lockRelative lockPath abort true with
                    | Some artifactLock ->
                        use heldLock = artifactLock
                        removePendingFiles store pendingRelative pending store.Limits.MaxScanEntries abort
                    | None when remaining > 0 && not (abort ()) ->
                        Thread.Sleep 10
                        tryCleanup (remaining - 1)
                    | None -> false

            tryCleanup 4

    /// Start a fresh artifact namespace without recursively deleting prior
    /// output. The caller must already own the job lifecycle: fresh Fogell
    /// runs also recursively replace that job's workspace, so concurrent fresh
    /// invocations of one job have never been supported. The old namespace is
    /// moved beneath private store state and the public key is left absent for
    /// the new attempt to populate.
    let rotateArtifactNamespace (store: ArtifactStore) (scopeKey: string) (abort: unit -> bool) =
        validateArtifactLimits store.Limits
        let target = artifactTarget store scopeKey

        match Native.openDirectoryIfPresentWithoutLinks target with
        | Ok None -> ()
        | Error _ -> raise (artifactFailure ())
        | Ok(Some probe) ->
            use probe = probe
            let _, _, lockRelative, lockPath = artifactSidecar store scopeKey

            // A fresh caller owns the job lifecycle; a busy prior writer is
            // an ownership conflict, so refuse without waiting indefinitely.
            match acquireArtifactLock store.Root lockRelative lockPath abort true with
            | None -> raise (artifactFailure ())
            | Some artifactLock ->
                use heldLock = artifactLock
                let historyRelative =
                    Path.Combine(
                        ".fogell-artifact-history",
                        artifactBuildId scopeKey,
                        Guid.NewGuid().ToString "N")

                match
                    Native.atomicRenameBetweenRootsWithoutLinks
                        store.Root
                        scopeKey
                        store.Root
                        historyRelative
                with
                | Ok() -> ()
                | Error _ -> raise (artifactFailure ())

    let private enumerateArtifactFiles
        (root: string)
        (scanLimit: int)
        (abort: unit -> bool)
        (onFile: string -> unit)
        =
        // Queue only logical paths. Each is reopened under the no-follow policy
        // when visited, so a broad tree cannot accumulate one live descriptor
        // per sibling directory.
        let pending = Stack<string>()
        let mutable entries = 0
        let mutable aborted = false

        match Native.openDirectoryIfPresentWithoutLinks root with
        | Ok(Some descriptor) ->
            descriptor.Dispose()
            pending.Push("")
        | Ok None -> ()
        | Error _ -> raise (artifactFailure ())

        while pending.Count > 0 && not aborted do
            if abort () then
                aborted <- true
            else
                let logical = pending.Pop()
                let path =
                    if String.IsNullOrEmpty logical then root
                    else Path.Combine(root, logical.Replace('/', Path.DirectorySeparatorChar))

                use descriptor =
                    match Native.openDirectoryWithoutLinks path with
                    | Ok descriptor -> descriptor
                    | Error _ -> raise (artifactFailure ())

                use children =
                    DirectoryInfo(Native.directoryDescriptorPath descriptor)
                        .EnumerateFileSystemInfos()
                        .GetEnumerator()

                while children.MoveNext() && not aborted do
                    if abort () then
                        aborted <- true
                    elif entries >= scanLimit then
                        raise (ArtifactLimitExceededException ArtifactLimitReason.ScanEntries)
                    else
                        entries <- entries + 1
                        let entry = children.Current
                        let relative =
                            if String.IsNullOrEmpty logical then entry.Name else logical + "/" + entry.Name
                        let isDirectory = entry :? DirectoryInfo
                        let isLink = entry.Attributes.HasFlag FileAttributes.ReparsePoint

                        if isDirectory then
                            // A linked directory is never traversed. Validate
                            // an ordinary child descriptor now, then reopen
                            // it by its logical path on visit without holding
                            // unbounded sibling descriptors.
                            if not isLink then
                                match Native.openChildDirectoryWithoutLinks descriptor entry.Name with
                                | Ok child ->
                                    child.Dispose()
                                    pending.Push relative
                                | Error _ -> raise (artifactFailure ())
                        else
                            onFile relative

        aborted

    let private retainedArtifacts (target: string) (limits: ArtifactLimits) (abort: unit -> bool) =
        let retained = Dictionary<string, int64>(StringComparer.Ordinal)
        let mutable bytes = 0L
        let mutable files = 0

        let aborted =
            enumerateArtifactFiles target limits.MaxScanEntries abort (fun relative ->
                let length =
                    match Native.openFileWithoutLinks target (relative.Replace('/', Path.DirectorySeparatorChar)) with
                    | Error _ -> raise (artifactFailure ())
                    | Ok stream ->
                        use stream = stream
                        stream.Length

                if length > limits.MaxFileBytes then
                    raise (ArtifactLimitExceededException ArtifactLimitReason.FileBytes)

                if bytes > limits.MaxTotalBytes - length then
                    raise (ArtifactLimitExceededException ArtifactLimitReason.TotalBytes)

                if files >= limits.MaxFiles then
                    raise (ArtifactLimitExceededException ArtifactLimitReason.FileCount)

                retained.[relative] <- length
                bytes <- bytes + length
                files <- files + 1)

        retained, bytes, files, aborted

    let private selectedArtifacts
        (workspace: string)
        (patterns: string list)
        (limits: ArtifactLimits)
        (abort: unit -> bool)
        =
        let mutable compiledPatterns = 0
        let matchers =
            patterns
            |> List.map (fun pattern ->
                if compiledPatterns >= limits.MaxScanEntries then
                    raise (ArtifactLimitExceededException ArtifactLimitReason.ScanEntries)
                compiledPatterns <- compiledPatterns + 1
                let compiled = compileGlobRegex false pattern
                let regex = Regex(compiled.ToString(), compiled.Options ||| RegexOptions.NonBacktracking)
                fun (relative: string) -> regex.IsMatch relative)
        let selected = List<string>()
        let seen = HashSet<string>(StringComparer.Ordinal)
        let mutable matcherEvaluations = 0

        let aborted =
            if List.isEmpty matchers then false
            else
                enumerateArtifactFiles workspace limits.MaxScanEntries abort (fun relative ->
                    let matches =
                        matchers |> List.exists (fun matcher ->
                            if matcherEvaluations >= limits.MaxScanEntries then
                                raise (ArtifactLimitExceededException ArtifactLimitReason.ScanEntries)
                            matcherEvaluations <- matcherEvaluations + 1
                            matcher relative)
                    if matches then
                        if seen.Add relative then
                            if selected.Count >= limits.MaxFiles then
                                raise (ArtifactLimitExceededException ArtifactLimitReason.FileCount)
                            selected.Add relative)

        selected |> Seq.sort |> Seq.toList, aborted

    let internal stageArtifactUsing
        (flush: FileStream -> unit)
        (store: ArtifactStore)
        (workspace: string)
        (pendingRelative: string)
        (relative: string)
        (alreadyHeldBytes: int64)
        (abort: unit -> bool)
        =
        let temporaryRelative = Path.Combine(pendingRelative, Guid.NewGuid().ToString("N") + ".part")
        let mutable stagedBytes = 0L
        let mutable aborted = false
        let buffer = Array.zeroCreate<byte> 65536

        let mutable preserveTemporary = false

        try
            match Native.openFileWithoutLinks workspace (relative.Replace('/', Path.DirectorySeparatorChar)) with
            | Error _ -> raise (artifactFailure ())
            | Ok source ->
                use input = source
                use output =
                    match Native.createNewFileWithoutLinks store.Root temporaryRelative with
                    | Ok stream -> stream
                    | Error _ -> raise (artifactFailure ())

                let mutable reading = true

                while reading && not aborted do
                    if abort () then
                        aborted <- true
                    else
                        let count = input.Read(buffer, 0, buffer.Length)

                        if count = 0 then
                            reading <- false
                        else
                            let chunk = int64 count

                            // Charge the observed bytes before each write. This
                            // catches a source which grows after descriptor open.
                            if stagedBytes > store.Limits.MaxFileBytes - chunk then
                                raise (ArtifactLimitExceededException ArtifactLimitReason.FileBytes)

                            if stagedBytes > store.Limits.MaxTotalBytes - alreadyHeldBytes - chunk then
                                raise (ArtifactLimitExceededException ArtifactLimitReason.TotalBytes)

                            output.Write(buffer, 0, count)
                            stagedBytes <- stagedBytes + chunk

                // A cancelled sidecar will be removed, so do not wait for a
                // durable flush (or let its I/O error replace cancellation).
                if aborted || abort () then
                    aborted <- true
                else
                    flush output

            if abort () then
                aborted <- true

            if aborted then
                None
            else
                preserveTemporary <- true
                Some(temporaryRelative, stagedBytes)
        finally
            if not preserveTemporary then
                Native.deleteFileWithoutLinks store.Root temporaryRelative |> ignore

    let private stageArtifact store workspace pendingRelative relative alreadyHeldBytes abort =
        stageArtifactUsing (fun output -> output.Flush(true)) store workspace pendingRelative relative alreadyHeldBytes abort

    /// Copy matched files into this attempt's artifact store under `buildKey`,
    /// preserving relative layout. Limits cover the retained files for this
    /// attempt plus the active sidecar file; historical snapshots and store
    /// retention are deliberately outside this admission boundary. Copies are
    /// cancellable within a file. A completed file remains published after a
    /// later abort; the active file stays in the sidecar and is deleted, so it
    /// cannot appear in a frozen snapshot. An overwrite needs headroom for its
    /// old retained bytes and its staged replacement until atomic promotion.
    let archiveWithAbort (store: ArtifactStore) (buildKey: string) (workspace: string) (patterns: string list) (abort: unit -> bool) =
        validateArtifactLimits store.Limits
        let target = artifactTarget store buildKey
        requireUnlinkedArtifactTarget target
        let pendingRelative, pending, lockRelative, lockPath = artifactSidecar store buildKey

        match acquireArtifactLock store.Root lockRelative lockPath abort false with
        | None -> [], true
        | Some artifactLock ->
            use heldLock = artifactLock
            if not (removePendingFiles store pendingRelative pending store.Limits.MaxScanEntries abort) then
                if abort () then [], true
                else raise (artifactFailure ())
            else
                let retained, initialRetainedBytes, initialRetainedFiles, retainedAborted =
                    retainedArtifacts target store.Limits abort
                let mutable retainedBytes = initialRetainedBytes
                let mutable retainedFiles = initialRetainedFiles

                if retainedAborted || abort () then
                    [], true
                else
                    let matched, scanAborted = selectedArtifacts workspace patterns store.Limits abort

                    if scanAborted || abort () then
                        [], true
                    else
                        let published = List<string>()
                        let mutable aborted = false

                        for relative in matched do
                            if not aborted then
                                if abort () then
                                    aborted <- true
                                else
                                    let previous =
                                        match retained.TryGetValue relative with
                                        | true, bytes -> bytes
                                        | _ -> 0L

                                    let existed = retained.ContainsKey relative

                                    if not existed && retainedFiles >= store.Limits.MaxFiles then
                                        raise (ArtifactLimitExceededException ArtifactLimitReason.FileCount)

                                    match stageArtifact store workspace pendingRelative relative retainedBytes abort with
                                    | None -> aborted <- true
                                    | Some (temporaryRelative, bytes) ->
                                        try
                                            if abort () then
                                                aborted <- true
                                            else
                                                match
                                                    Native.atomicRenameBetweenRootsWithoutLinks
                                                        store.Root
                                                        temporaryRelative
                                                        target
                                                        (relative.Replace('/', Path.DirectorySeparatorChar))
                                                with
                                                | Error _ -> raise (artifactFailure ())
                                                | Ok() -> ()
                                                retained.[relative] <- bytes
                                                retainedBytes <- retainedBytes + bytes - previous
                                                if not existed then
                                                    retainedFiles <- retainedFiles + 1
                                                published.Add relative
                                        finally
                                            Native.deleteFileWithoutLinks store.Root temporaryRelative |> ignore

                        List.ofSeq published, aborted || abort ()

    let archive store buildKey workspace patterns =
        archiveWithAbort store buildKey workspace patterns (fun () -> false) |> fst

    let private parseJUnitCore
        (onFailure: Fogell.Domain.ExecutionDiagnostic -> unit)
        (scanLimit: int)
        (workspace: string)
        (patterns: string list)
        (not_beforeSince: int64 option)
        (abort: unit -> bool)
        : Result<int * int * int * single option, JUnitProblem> =
        let files, selectionProblem =
            match expandJUnitGlobs scanLimit workspace patterns abort with
            | Ok selected -> selected, None
            | Error problem -> [], Some problem

        // REVIEW FIX (Codex, PR #14 round 12): the mirror of the archive zero-match
        // case. With no matching report the scan can still have been long, and an
        // interrupt firing during it was reported as "no test report matched" — a
        // pattern problem the user would go and debug — instead of an abort.
        let scanInterrupted =
            match selectionProblem with
            | Some Interrupted -> true
            | _ -> false

        if scanInterrupted then
            Error Interrupted
        elif abort () then
            Error Interrupted
        elif Option.isSome selectionProblem then
            Error selectionProblem.Value
        elif List.isEmpty files then
            // Keep absence distinct from a report which matched but could not be
            // read. `allow_empty` may permit this condition, but must never
            // suppress a genuine I/O or parse failure.
            Error NoReports
        else
            // Accumulate wider than the Java summary surface so neither a very large
            // child population nor synthetic failures can wrap into false success.
            let mutable total = 0L
            let mutable failed = 0L
            let mutable skipped = 0L
            // JUnit stores, parses, clamps, and adds durations as JVM float.
            // Keep every addition binary32: accumulating as double and narrowing
            // once changes observable summaries at the 2^24 boundary.
            let mutable duration = Some 0.0f
            let mutable immediateProblem: JUnitProblem option = None
            let mutable sawMissingIdentity = false

            let mutable aborted = false

            for candidate in files do
              if not aborted && Option.isNone immediateProblem then
                let relative = candidate.Relative

                if abort () then
                    aborted <- true
                else
                try
                    match candidate.PhysicalTarget with
                    | None ->
                        match not_beforeSince with
                        | Some _ ->
                            immediateProblem <-
                                Some(
                                    Unreadable(
                                        $"unparsable test report(s): {relative}: FileNotFoundException"))
                        | None ->
                            total <- total + 1L
                            failed <- failed + 1L
                    | Some physicalTarget ->
                        // Resolve once, open once, and use this handle for length,
                        // timestamp, and XML bytes. Retargeting the logical link
                        // cannot split metadata from parsed content. `/proc/self/fd`
                        // names the open inode on the pinned Linux agent.
                        use stream =
                            new FileStream(
                                physicalTarget,
                                FileMode.Open,
                                FileAccess.Read,
                                FileShare.ReadWrite ||| FileShare.Delete)

                        match not_beforeSince with
                        | Some buildStartTimeInMillis ->
                            let modified =
                                File.GetLastWriteTimeUtc(stream.SafeFileHandle)
                                |> DateTimeOffset
                                |> fun value -> value.ToUnixTimeMilliseconds()

                            // Pinned JUnit tolerates timestamp precision by 3000
                            // ms and retains equality at the adjusted boundary.
                            if modified < buildStartTimeInMillis - 3000L then
                                raise (OldJUnitReportException())
                        | None -> ()

                        if stream.Length = 0L then
                            raise (EmptyJUnitReportException())

                        let doc = Xml.Linq.XDocument.Load(stream)

                        let directElements name (element: Xml.Linq.XElement) =
                            // dom4j's Element.elements(String)/element(String)
                            // compare the exact, case-sensitive local name. The
                            // namespace URI and prefix are not part of the match.
                            element.Elements()
                            |> Seq.filter (fun child -> child.Name.LocalName = name)

                        let firstAttribute name (element: Xml.Linq.XElement) =
                            // dom4j stores namespace declarations as Namespace
                            // nodes, not Attributes. LINQ exposes them as
                            // attributes, so exclude them before matching the
                            // same exact local-name contract in document order.
                            element.Attributes()
                            |> Seq.tryFind (fun attribute ->
                                not attribute.IsNamespaceDeclaration
                                && attribute.Name.LocalName = name)

                        let hasDirectChild name (element: Xml.Linq.XElement) =
                            directElements name element |> Seq.isEmpty |> not

                        let hasAttribute name (element: Xml.Linq.XElement) =
                            firstAttribute name element |> Option.isSome

                        let parseDuration (raw: string) =
                            // Pinned TimeToFloat removes commas, tries
                            // Float.parseFloat, then DecimalFormat.parse (which
                            // may accept a numeric prefix), and defaults to zero.
                            let javaWhitespace = [| for code in 0..32 -> char code |]
                            let cleaned = raw.Replace(",", "")
                            // Float.parseFloat accepts its documented leading and
                            // trailing ASCII whitespace. DecimalFormat.parse does
                            // not, so retain both views for the two-stage path.
                            let text = cleaned.Trim(javaWhitespace)
                            let styles = Globalization.NumberStyles.Float
                            let invariant = Globalization.CultureInfo.InvariantCulture

                            let normalizeDecimalDigits (value: string) =
                                // DecimalFormat accepts every Unicode Nd digit,
                                // whereas Float.parseFloat is ASCII-only. The pinned
                                // parser walks UTF-16 chars, not grapheme clusters or
                                // scalar Runes: map one BMP digit to one ASCII digit
                                // and preserve combining marks/surrogates verbatim.
                                value
                                |> Seq.map (fun codeUnit ->
                                    let digit = Globalization.CharUnicodeInfo.GetDecimalDigitValue codeUnit
                                    if digit >= 0 then char (int '0' + digit) else codeUnit)
                                |> Seq.toArray
                                |> String

                            let decimalToken =
                                Regex.IsMatch(
                                    text,
                                    @"^[+-]?(?:NaN|Infinity|(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?[fFdD]?)$"
                                )

                            let hexadecimalToken =
                                Regex.IsMatch(
                                    text,
                                    @"^[+-]?0[xX](?:[0-9a-fA-F]+(?:\.[0-9a-fA-F]*)?|\.[0-9a-fA-F]+)[pP][+-]?[0-9]+[fFdD]?$"
                                )

                            let parsed =
                                if hexadecimalToken then
                                    // Java accepts hexadecimal float literals. A
                                    // double-mediated conversion can double-round,
                                    // so keep counts available but refuse duration
                                    // access instead of guessing at binary32 edges.
                                    None
                                elif decimalToken then
                                    let core =
                                        if text.Length > 0 && "fFdD".Contains text.[text.Length - 1] then
                                            text.Substring(0, text.Length - 1)
                                        else
                                            text

                                    match core with
                                    | "NaN" -> Some Single.NaN
                                    | "Infinity"
                                    | "+Infinity" -> Some Single.PositiveInfinity
                                    | "-Infinity" -> Some Single.NegativeInfinity
                                    | _ ->
                                        match Single.TryParse(core, styles, invariant) with
                                        | true, value -> Some value
                                        | _ -> Some 0.0f
                                else
                                    // Pinned default DecimalFormat accepts only an
                                    // uppercase-E exponent with no positive sign.
                                    // Lowercase `1e2x` and `1E+2x` both stop at 1.
                                    let fallbackText = normalizeDecimalDigits cleaned

                                    if fallbackText.StartsWith("NaN", StringComparison.Ordinal) then
                                        Some Single.NaN
                                    elif fallbackText.StartsWith("∞", StringComparison.Ordinal) then
                                        Some Single.PositiveInfinity
                                    elif fallbackText.StartsWith("-∞", StringComparison.Ordinal) then
                                        Some Single.NegativeInfinity
                                    else
                                        let prefix =
                                            Regex.Match(
                                                fallbackText,
                                                @"^-?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:E-?[0-9]+)?"
                                            )

                                        let oversizedExponent =
                                            let exponentIndex = prefix.Value.IndexOf('E')

                                            exponentIndex >= 0
                                            && prefix.Value.Substring(exponentIndex + 1).TrimStart('-').Length > 3

                                        if String.IsNullOrEmpty prefix.Value then
                                            Some 0.0f
                                        elif oversizedExponent then
                                            // DecimalFormat's oversized-exponent
                                            // overflow/parse-stop behavior diverges
                                            // from Double.TryParse. Preserve counts
                                            // and refuse duration beyond the measured
                                            // three-digit exponent boundary.
                                            None
                                        else
                                            // DecimalFormat returns Long for an
                                            // integral value and Double otherwise.
                                            // Every integer inside the subsequent
                                            // [0, 31536000] clamp is exactly binary64;
                                            // outside it the clamp erases the width
                                            // distinction. Double->Float is therefore
                                            // the exact observable fallback path.
                                            match Double.TryParse(prefix.Value, styles, invariant) with
                                            | true, value -> Some(single value)
                                            | _ -> Some 0.0f

                            // Java Math.min/max propagate NaN, clamp infinities,
                            // and turn negative zero into positive zero here.
                            parsed
                            |> Option.map (fun value -> MathF.Max(0.0f, MathF.Min(31_536_000.0f, value)))

                        let addDuration contribution =
                            duration <-
                                match duration, contribution with
                                | Some total, Some value -> Some(total + value)
                                | _ -> None

                        let hasCaseIdentity
                            (owner: Xml.Linq.XElement)
                            (testCase: Xml.Linq.XElement)
                            =
                            // SuiteResult first uses testcase@classname, then the
                            // owning element's name. CaseResult has one final legacy
                            // fallback: a dotted testcase name supplies its class
                            // prefix. Attribute presence is the boundary; Java keeps
                            // an explicitly empty classname/name rather than treating
                            // it as missing.
                            hasAttribute "classname" testCase
                            || hasAttribute "name" owner
                            || match firstAttribute "name" testCase with
                               | None -> false
                               | Some testName -> testName.Value.Contains(".", StringComparison.Ordinal)

                        let tallyCase (element: Xml.Linq.XElement) =
                            total <- total + 1L

                            // TestResult.freeze classifies skipped first. This
                            // applies both to ordinary testcase elements and to the
                            // synthetic case constructed from a suite-level error.
                            if hasDirectChild "skipped" element then
                                skipped <- skipped + 1L
                            elif hasDirectChild "failure" element || hasDirectChild "error" element then
                                failed <- failed + 1L
                                let attr name = firstAttribute name element |> Option.map (fun a -> a.Value) |> Option.defaultValue null
                                let failure =
                                    Seq.append (directElements "failure" element) (directElements "error" element)
                                    |> Seq.tryHead
                                let message = failure |> Option.map (fun e ->
                                    let summary = firstAttribute "message" e |> Option.map (fun a -> a.Value) |> Option.defaultValue ""
                                    summary + "\n" + e.Value) |> Option.defaultValue "test failed"
                                let line = match Int64.TryParse(attr "line") with | true, n when n > 0L -> Nullable n | _ -> Nullable()
                                try
                                    onFailure
                                        { Fogell.Domain.ExecutionDiagnostic.create "test" "failure" message with
                                            TestName = attr "name"; TestClass = attr "classname"
                                            SourcePath = attr "file"; SourceLine = line; ReportPath = relative }
                                with ex -> raise (DiagnosticCallbackException ex)

                        match doc.Root with
                        | null -> ()
                        | root ->
                            // SuiteResult.parse walks direct nested <testsuite>
                            // elements. Use an explicit work stack: report nesting is
                            // untrusted input and must not consume the native call stack.
                            let pending =
                                System.Collections.Generic.Stack<Xml.Linq.XElement * bool>()

                            pending.Push(root, false)

                            while pending.Count > 0 do
                                let element, visitOwner = pending.Pop()

                                if visitOwner then
                                    // parseSuite owns direct cases/errors on every element
                                    // it reaches: the document root plus descendants reached
                                    // exclusively through direct testsuite edges. It does not
                                    // require the owner itself to be named testsuite.
                                    // A direct owner error is one synthetic case and remains
                                    // skipped when that owner also has a direct skipped marker.
                                    let directCases = directElements "testcase" element |> Seq.toArray
                                    let hasDirectError = hasDirectChild "error" element

                                    if hasDirectError then
                                        tallyCase element

                                    for testCase in directCases do
                                        let hasClassFallback =
                                            hasAttribute "classname" testCase
                                            || hasAttribute "name" element

                                        // CaseResult reads testcase@name only when both
                                        // class fallbacks are absent. A missing attribute
                                        // faults at String.contains before the later
                                        // null-className failure; name="" is present and
                                        // therefore stays on FG-211's later identity path.
                                        if
                                            not hasClassFallback
                                            && not (hasAttribute "name" testCase)
                                        then
                                            raise (MissingJUnitTestNameException())

                                        if not (hasCaseIdentity element testCase) then
                                            // CaseResult construction succeeds with a null
                                            // className. The pinned plugin does not fault until
                                            // the global tally/package pass, after every matched
                                            // report has completed construction. Remember the
                                            // deferred fault while continuing to expose any later
                                            // construction-time missing-name/read failure.
                                            sawMissingIdentity <- true

                                        tallyCase testCase

                                    // SuiteResult exists only for an owner which
                                    // contributes a direct testcase or synthetic
                                    // direct error. A present suite time is
                                    // authoritative even when it parses to zero;
                                    // otherwise add direct case times in document
                                    // order. Nested suites have already been
                                    // visited and added child-first.
                                    if hasDirectError || directCases.Length > 0 then
                                        let suiteDuration =
                                            match firstAttribute "time" element with
                                            | None ->
                                                directCases
                                                |> Array.fold (fun total testCase ->
                                                    match firstAttribute "time" testCase with
                                                    | None -> total
                                                    | Some time ->
                                                        match total, parseDuration time.Value with
                                                        | Some aggregate, Some value -> Some(aggregate + value)
                                                        | _ -> None) (Some 0.0f)
                                            | Some time -> parseDuration time.Value

                                        addDuration suiteDuration
                                else
                                    // The pinned recursive parser visits direct suite
                                    // children first, in document order, and only then
                                    // constructs the current owner. Push the continuation
                                    // first and children in reverse so this iterative walk
                                    // preserves that construction order without using
                                    // the native call stack.
                                    pending.Push(element, true)

                                    directElements "testsuite" element
                                    |> Seq.toArray
                                    |> Array.rev
                                    |> Array.iter (fun nested -> pending.Push(nested, false))
                with
                | :? DiagnosticCallbackException as ex -> raise ex.InnerException
                | :? OldJUnitReportException -> ()
                | :? EmptyJUnitReportException ->
                    total <- total + 1L
                    failed <- failed + 1L
                | (:? FileNotFoundException | :? DirectoryNotFoundException)
                    when Option.isNone not_beforeSince ->
                    // A wildcard-selected dangling target is one synthetic empty
                    // report. Timestamp filtering deliberately keeps the existing
                    // unreadable FileNotFound classification instead.
                    total <- total + 1L
                    failed <- failed + 1L
                | :? System.Xml.XmlException
                    when relative.EndsWith(".xml", StringComparison.Ordinal) ->
                    // Pinned junit-plugin 1416.vd753e036de5e:
                    // TestResult.parse(File, ...) catches DocumentException for a
                    // `.xml` path and adds one failed `[failed-to-read]` case. Empty
                    // files took the earlier extension-independent `[empty]` arm.
                    total <- total + 1L
                    failed <- failed + 1L
                | :? MissingJUnitTestNameException ->
                    immediateProblem <- Some(MissingTestName relative)
                | ex ->
                    immediateProblem <-
                        Some(Unreadable($"unparsable test report(s): {relative}: {ex.GetType().Name}"))

            // Same rule as the archive path: once a report has been parsed, an
            // interruption observed afterwards still counts.
            if not aborted && abort () then aborted <- true

            match aborted, immediateProblem, sawMissingIdentity with
            | true, _, _ -> Error Interrupted
            | false, Some problem, _ -> Error problem
            | false, None, true -> Error MissingIdentity
            | false, None, false
                when [ total; failed; skipped ]
                     |> List.forall (fun value -> value >= int64 Int32.MinValue && value <= int64 Int32.MaxValue) ->
                Ok(int total, int failed, int skipped, duration)
            | false, None, false -> Error(Unreadable "test report counts exceed the JUnit Integer summary range")

    let internal parseJUnitWithAbortUsingScanLimit scanLimit workspace patterns not_beforeSince abort =
        parseJUnitCore ignore scanLimit workspace patterns not_beforeSince abort

    let parseJUnitWithDiagnostics onFailure workspace patterns not_beforeSince abort =
        parseJUnitCore onFailure junitScanLimit workspace patterns not_beforeSince abort

    let parseJUnitWithAbort workspace patterns not_beforeSince abort =
        parseJUnitWithAbortUsingScanLimit
            junitScanLimit
            workspace
            patterns
            not_beforeSince
            abort

    let parseJUnit (workspace: string) (patterns: string list) =
        match parseJUnitWithAbort workspace patterns None (fun () -> false) with
        | Ok(total, failed, skipped, _) -> Ok(total, failed, skipped)
        | Error Interrupted -> Error "interrupted"
        | Error NoReports -> Error "no test report matched the pattern"
        | Error(MissingTestName _) -> Error JUnitDiagnostics.MissingTestNameMessage
        | Error MissingIdentity -> Error "JUnit testcase has no resolvable class identity"
        | Error(Unreadable m) -> Error m

module Stash =

    let private safeDiagnosticPath (value: string) =
        let builder = Text.StringBuilder()
        let limit = min value.Length 160

        for index in 0 .. limit - 1 do
            let c = value.[index]
            if Char.IsControl c then builder.Append($"\\u{int c:X4}") |> ignore
            else builder.Append c |> ignore

        if value.Length > limit then builder.Append "…" |> ignore
        builder.ToString()

    let private deleteDirectoryBestEffort path =
        try
            if IO.Directory.Exists path then IO.Directory.Delete(path, true)
        with _ ->
            ()

    [<RequireQualifiedAccess>]
    type SaveProblem =
        | SelectedPathRefused of relative: string * detail: string
        | StorageFailure of detail: string

        member this.Describe =
            match this with
            | SelectedPathRefused(relative, detail) ->
                $"stash refuses selected path ‘{safeDiagnosticPath relative}’: {detail}"
            | StorageFailure detail -> $"stash storage failed: {detail}"

    type private GlobToken =
        | Literal of character: char * caseSensitive: bool
        | AnyNonSeparator
        | StarNonSeparator
        | StarAny
        | GlobstarPrefixStart
        | GlobstarPrefixBody

    type private GlobSearchState =
        { Included: Set<int>
          Excluded: Set<int> list
          SegmentKind: int }

    type private GlobSearchPermit =
        | SearchTransition
        | SearchAborted
        | SearchExhausted

    /// Compile the same language as Publish.compileGlobRegex into a small NFA.
    /// GlobstarPrefix represents the regex rewrite that lets `**/x` also match
    /// bare `x`; it either consumes no prefix or consumes through a slash.
    let private compileGlobProgram caseSensitive (pattern: string) =
        let segments = pattern.Replace('\\', '/').Trim().Split('/', StringSplitOptions.None)
        let tokens = Collections.Generic.List<GlobToken>()

        for index = 0 to segments.Length - 1 do
            let segment = segments.[index]

            if segment = "**" then
                if index = segments.Length - 1 then tokens.Add StarAny
                else
                    tokens.Add GlobstarPrefixStart
                    tokens.Add GlobstarPrefixBody
            else
                for character in segment do
                    match character with
                    | '*' -> tokens.Add StarNonSeparator
                    | '?' -> tokens.Add AnyNonSeparator
                    | literal -> tokens.Add(Literal(literal, caseSensitive))

                if index < segments.Length - 1 then
                    tokens.Add(Literal('/', true))

        tokens.ToArray()

    let private epsilonClosure (program: GlobToken array) (states: Set<int>) =
        let pending = Collections.Generic.Stack<int>(states)
        let reachable = Collections.Generic.HashSet<int>(states)

        while pending.Count > 0 do
            let state = pending.Pop()

            if state < program.Length then
                match program.[state] with
                | StarNonSeparator
                | StarAny ->
                    if reachable.Add(state + 1) then pending.Push(state + 1)
                | GlobstarPrefixStart ->
                    if reachable.Add(state + 2) then pending.Push(state + 2)
                | _ -> ()

        reachable |> Set.ofSeq

    let private stepGlobProgram (program: GlobToken array) (states: Set<int>) character =
        let next = Collections.Generic.HashSet<int>()

        for state in states do
            if state < program.Length then
                match program.[state] with
                | Literal(expected, caseSensitive) ->
                    let matches =
                        if caseSensitive then expected = character
                        else Char.ToUpperInvariant expected = Char.ToUpperInvariant character

                    if matches then next.Add(state + 1) |> ignore
                | AnyNonSeparator when character <> '/' -> next.Add(state + 1) |> ignore
                | StarNonSeparator when character <> '/' -> next.Add state |> ignore
                | StarAny when character <> '\n' -> next.Add state |> ignore
                | GlobstarPrefixStart when character <> '\n' ->
                    next.Add(state + 1) |> ignore
                    if character = '/' then next.Add(state + 2) |> ignore
                | GlobstarPrefixBody when character <> '\n' ->
                    next.Add state |> ignore
                    if character = '/' then next.Add(state + 1) |> ignore
                | _ -> ()

        epsilonClosure program (next |> Set.ofSeq)

    let private feedGlobProgram program states (value: string) =
        value |> Seq.fold (stepGlobProgram program) states

    let private globSearchAlphabet
        (includeProgram: GlobToken array)
        (excludePrograms: GlobToken array list)
        =
        let literalCharacters =
            seq {
                for program in includeProgram :: excludePrograms do
                    for token in program do
                        match token with
                        | Literal(character, false) ->
                            yield Char.ToLowerInvariant character
                            yield Char.ToUpperInvariant character
                        | Literal(character, true) -> yield character
                        | _ -> ()
                yield '/'
            }
            |> Seq.filter ((<>) '\u0000')
            |> Set.ofSeq

        // Literal characters are singleton NFA equivalence classes; every
        // nonliteral character shares one representative. By pigeonhole, if
        // fewer than all non-NUL UTF-16 code units are literal, one of the
        // first count+1 candidates is absent. Build this once per compiled
        // include, not once per directory reached by the workspace walk.
        let other =
            if literalCharacters.Count = int Char.MaxValue then
                None
            else
                seq { for code = 1 to literalCharacters.Count + 1 do yield char code }
                |> Seq.tryFind (fun character ->
                    character <> '/' && not (literalCharacters.Contains character))

        other
        |> Option.fold (fun values character -> Set.add character values) literalCharacters

    /// Decide whether an included file path can exist beneath a directory after
    /// the union of explicit and default excludes is applied. This is a language
    /// reachability question over the Ant glob NFAs, so an empty effective
    /// selection such as include `link/*.txt`, exclude `link/*` does not refuse a
    /// directory link, while any surviving admitted witness still does. The
    /// search admits only real Linux path shapes: non-empty components other than
    /// `.` and `..`, with no trailing or doubled separator.
    let private patternHasUnexcludedDescendant
        (includeProgram: GlobToken array)
        (excludePrograms: GlobToken array list)
        (alphabet: Set<char>)
        (relative: string)
        (permitTransition: unit -> GlobSearchPermit)
        =
        let initial program = epsilonClosure program (Set.singleton 0)
        let prefix = relative + "/"
        let included = feedGlobProgram includeProgram (initial includeProgram) prefix

        if Set.isEmpty included then
            false, false
        else
            let excluded =
                excludePrograms
                |> List.map (fun program -> feedGlobProgram program (initial program) prefix)
            let initialState =
                { Included = included
                  Excluded = excluded
                  SegmentKind = 0 }
            let pending = Collections.Generic.Queue<GlobSearchState>()
            let visited = Collections.Generic.HashSet<GlobSearchState>()
            let mutable witness = false
            let mutable aborted = false
            let mutable transitionBudgetExhausted = false
            pending.Enqueue initialState
            visited.Add initialState |> ignore

            let maxSearchStates = 10000

            while pending.Count > 0
                  && not witness
                  && not aborted
                  && not transitionBudgetExhausted
                  && visited.Count <= maxSearchStates do
                let state = pending.Dequeue()

                if
                    state.SegmentKind = 3
                    && state.Included.Contains includeProgram.Length
                    && List.forall2
                        (fun (program: GlobToken array) (excludedState: Set<int>) ->
                            not (excludedState.Contains program.Length))
                        excludePrograms
                        state.Excluded
                then
                    witness <- true
                else
                    for character in alphabet do
                        if not aborted && not transitionBudgetExhausted then
                            match permitTransition () with
                            | SearchAborted -> aborted <- true
                            | SearchExhausted -> transitionBudgetExhausted <- true
                            | SearchTransition ->
                                let nextSegmentKind =
                                    if character = '/' then
                                        if state.SegmentKind = 3 then Some 0 else None
                                    else
                                        match state.SegmentKind, character with
                                        | 0, '.' -> Some 1
                                        | 0, _ -> Some 3
                                        | 1, '.' -> Some 2
                                        | 1, _
                                        | 2, _
                                        | 3, _ -> Some 3
                                        | _ -> None

                                match nextSegmentKind with
                                | None -> ()
                                | Some segmentKind ->
                                    let nextIncluded = stepGlobProgram includeProgram state.Included character

                                    if not (Set.isEmpty nextIncluded) then
                                        let next =
                                            { Included = nextIncluded
                                              Excluded =
                                                List.map2
                                                    (fun (program: GlobToken array) (excludedState: Set<int>) ->
                                                        stepGlobProgram program excludedState character)
                                                    excludePrograms
                                                    state.Excluded
                                              SegmentKind = segmentKind }

                                        if visited.Add next then pending.Enqueue next

            // Exhaustion is fail closed: a surviving selected descendant may
            // exist, so the caller must refuse a link or descend an ordinary
            // directory. Cancellation is reported separately and outranks that
            // conservative answer at the stash/unstash publication boundary.
            witness || visited.Count > maxSearchStates || transitionBudgetExhausted, aborted

    /// Enumerate only physical workspace directories. Link targets are never
    /// entered: selected file links and selected directory prefixes become a
    /// named refusal at their lexical path, while unselected links are ignored.
    let private entryIsSymbolicLink (entry: FileSystemInfo) =
        not (isNull entry.LinkTarget)

    let private selectWithoutFollowingLinks
        (workspace: string)
        (patterns: string list)
        (excludes: string list)
        (useDefaultExcludes: bool)
        (abort: unit -> bool)
        =
        let rawIncludes = if List.isEmpty patterns then [ "**" ] else patterns
        let normalizePattern (pattern: string) = pattern.Replace('\\', '/').Trim()
        let includes =
            rawIncludes
            |> List.filter (fun includePattern ->
                excludes
                |> List.exists (fun excludePattern ->
                    String.Equals(
                        normalizePattern includePattern,
                        normalizePattern excludePattern,
                        StringComparison.OrdinalIgnoreCase))
                |> not)
        let includeMatchers = includes |> List.map (Publish.compileGlobMatcher false)
        let excludeMatchers = excludes |> List.map (Publish.compileGlobMatcher false)
        let includePrograms = includes |> List.map (compileGlobProgram false)
        let excludePrograms =
            (excludes |> List.map (compileGlobProgram false))
            @ if useDefaultExcludes then
                  Publish.antDefaultExcludePatterns |> List.map (compileGlobProgram true)
              else
                  []
        let includeSearches =
            includePrograms
            |> List.map (fun program -> program, globSearchAlphabet program excludePrograms)
        let files = Collections.Generic.List<string>()
        let pending = Collections.Generic.Stack<Microsoft.Win32.SafeHandles.SafeFileHandle * string>()
        let mutable problem: SaveProblem option = None
        let mutable aborted = abort ()
        // This budget is shared by every include and directory in one stash
        // selection. The per-search state cap alone is insufficient because an
        // admitted pattern can contribute thousands of distinct literal
        // characters to the transition alphabet.
        let maxGlobSearchTransitions = 25_000
        let abortPollInterval = 256
        let mutable globSearchTransitions = 0

        match Native.openDirectoryIfPresentWithoutLinks workspace with
        | Ok(Some root) -> pending.Push(root, "")
        | Ok None -> ()
        | Error why -> problem <- Some(SaveProblem.StorageFailure why)

        let explicitlyExcluded relative =
            excludeMatchers |> List.exists (fun matches -> matches relative)

        let defaultExcluded relative =
            useDefaultExcludes && Publish.isAntDefaultExcluded relative

        let directoryHasSelection relative =
            let mutable selected = false

            for includeProgram, alphabet in includeSearches do
                if not selected && not aborted then
                    let permitTransition () =
                        if
                            globSearchTransitions % abortPollInterval = 0
                            && abort ()
                        then
                            SearchAborted
                        elif globSearchTransitions >= maxGlobSearchTransitions then
                            SearchExhausted
                        else
                            globSearchTransitions <- globSearchTransitions + 1
                            SearchTransition

                    let hasSelection, searchAborted =
                        patternHasUnexcludedDescendant
                            includeProgram
                            excludePrograms
                            alphabet
                            relative
                            permitTransition

                    selected <- hasSelection
                    if searchAborted then aborted <- true

            selected

        try
            while pending.Count > 0 && Option.isNone problem && not aborted do
                let descriptor, logicalDirectory = pending.Pop()
                use descriptor = descriptor

                use entries =
                    DirectoryInfo(Native.directoryDescriptorPath descriptor)
                        .EnumerateFileSystemInfos()
                        .GetEnumerator()

                while entries.MoveNext() && Option.isNone problem && not aborted do
                    if abort () then
                        aborted <- true
                    else
                        let entry = entries.Current
                        let relative =
                            if logicalDirectory = "" then entry.Name
                            else logicalDirectory + "/" + entry.Name

                        let isLink = entryIsSymbolicLink entry
                        let isDirectory = entry :? DirectoryInfo
                        let selected =
                            if isDirectory then
                                directoryHasSelection relative
                            else
                                includeMatchers |> List.exists (fun matches -> matches relative)

                        let excluded =
                            defaultExcluded relative
                            || if not isDirectory then
                                   explicitlyExcluded relative
                               else
                                   false

                        if isLink then
                            if selected && not excluded then
                                problem <-
                                    Some(
                                        SaveProblem.SelectedPathRefused(
                                            relative,
                                            "selected symbolic links and linked directory descendants are not stashed"))
                        elif isDirectory && selected then
                            if not excluded then
                                match Native.openChildDirectoryWithoutLinks descriptor entry.Name with
                                | Ok child -> pending.Push(child, relative)
                                | Error why ->
                                    problem <-
                                        Some(
                                            SaveProblem.SelectedPathRefused(
                                                relative,
                                                why))
                        elif selected && not excluded then
                            files.Add relative
        with ex ->
            problem <-
                Some(
                    SaveProblem.StorageFailure(
                        $"could not enumerate stash inputs ({ex.GetType().Name})"))

        while pending.Count > 0 do
            let descriptor, _ = pending.Pop()
            descriptor.Dispose()

        problem, (files |> Seq.distinct |> Seq.sort |> Seq.toList), aborted

    let private safeKey (name: string) =
        let slug =
            String(name |> Seq.map (fun c -> if Char.IsLetterOrDigit c then c else '-') |> Seq.toArray)
            |> fun s -> s.Trim '-'
            |> fun s -> if s = "" then "stash" else s.Substring(0, min 40 s.Length)

        use sha = Security.Cryptography.SHA256.Create()
        let digest = sha.ComputeHash(Text.Encoding.UTF8.GetBytes name) |> Convert.ToHexString
        slug + "-" + digest.Substring(0, 12).ToLowerInvariant()

    let private dir (store: StashStore) (buildKey: string) (name: string) =
        let root = IO.Path.GetFullPath(IO.Path.Combine(store.Root, buildKey, "stashes"))
        let target = IO.Path.GetFullPath(IO.Path.Combine(root, safeKey name))

        // Belt and braces: assert containment rather than trusting the slug.
        if not (target.StartsWith(root + string IO.Path.DirectorySeparatorChar)) then
            failwith $"stash name '{name}' does not resolve beneath the stash root"

        target

    /// Copy the matched files out of the workspace and into controller-side storage.
    let save
        (store: StashStore)
        (buildKey: string)
        (workspace: string)
        (name: string)
        (patterns: string list)
        (excludes: string list)
        (useDefaultExcludes: bool)
        (abort: unit -> bool)
        : Result<string list * bool, SaveProblem> =
        let target = dir store buildKey name

        let selectionProblem, matched, selectionAborted =
            selectWithoutFollowingLinks workspace patterns excludes useDefaultExcludes abort

        // Same during-and-after-copy polling as the archive path: a `stash` inside a
        // `timeout` used to be able to finish AFTER the deadline with the build still
        // green, because nothing downstream observed the expiry. (FG-002e's pattern:
        // every early return is a missed poll.)
        let mutable aborted = selectionAborted || abort ()
        let copied = System.Collections.Generic.List<string>()
        let mutable problem = selectionProblem
        let staging = target + ".new-" + Guid.NewGuid().ToString "N"

        if Option.isNone problem && not aborted then
            try
                IO.Directory.CreateDirectory staging |> ignore
            with ex ->
                problem <-
                    Some(
                        SaveProblem.StorageFailure(
                            $"could not create staged stash ({ex.GetType().Name})"))

        for relative in matched do
            if not aborted && Option.isNone problem then
                if abort () then
                    aborted <- true
                else
                    match Native.openFileWithoutLinks workspace relative with
                    | Error why ->
                        problem <- Some(SaveProblem.SelectedPathRefused(relative, why))
                    | Ok source ->
                        use source = source
                        try
                            let sourceMode = Native.fileMode source
                            let sourceModified = Native.fileLastWriteTimeUtc source
                            let dest = IO.Path.Combine(staging, relative)
                            IO.Directory.CreateDirectory(IO.Path.GetDirectoryName dest) |> ignore
                            use output =
                                new FileStream(
                                    dest,
                                    FileMode.CreateNew,
                                    FileAccess.Write,
                                    FileShare.None)
                            source.CopyTo output
                            Native.setFileLastWriteTimeUtc output sourceModified
                            Native.setFileMode output sourceMode
                            copied.Add relative
                            if abort () then aborted <- true
                        with ex ->
                            problem <-
                                Some(
                                    SaveProblem.StorageFailure(
                                        $"could not stage ‘{safeDiagnosticPath relative}’ ({ex.GetType().Name})"))

        match problem, aborted with
        | _, true ->
            deleteDirectoryBestEffort staging
            // `copied` describes files written only to the private staging tree.
            // Cancellation discards that tree, so the committed/public result is
            // empty even when the final poll observes cancellation after a copy.
            Ok([], true)
        | Some refusal, false ->
            deleteDirectoryBestEffort staging
            Error refusal
        | None, false ->
            // Publish only a completely validated copy. In particular, a refused
            // same-name replacement leaves the prior stash intact rather than
            // replacing it with a partial archive assembled before the bad link.
            let backup = target + ".old-" + Guid.NewGuid().ToString "N"

            try
                if IO.Directory.Exists target then IO.Directory.Move(target, backup)

                try
                    IO.Directory.Move(staging, target)
                with _ ->
                    if IO.Directory.Exists backup && not (IO.Directory.Exists target) then
                        IO.Directory.Move(backup, target)
                    reraise()

                if IO.Directory.Exists backup then
                    try
                        IO.Directory.Delete(backup, true)
                    with _ ->
                        // The target move above is the commit point. Cleanup of
                        // the now-obsolete prior tree cannot turn a committed
                        // stash into a reported failure; a later maintenance
                        // sweep may remove an orphaned .old-* directory.
                        ()
                Ok(List.ofSeq copied, false)
            with ex ->
                deleteDirectoryBestEffort staging
                Error(SaveProblem.StorageFailure($"could not publish staged stash ({ex.GetType().Name})"))

    /// Restore a stash into the workspace. Missing name is an error, never a silent
    /// no-op: a build that carries on with none of the files it asked for is the
    /// silent-loss shape this project exists to avoid.
    let restore
        (store: StashStore)
        (buildKey: string)
        (workspace: string)
        (name: string)
        (abort: unit -> bool)
        =
        let source = dir store buildKey name

        if not (IO.Directory.Exists source) then
            Error $"No such saved stash ‘{name}’"
        else
            let selectionProblem, files, selectionAborted =
                selectWithoutFollowingLinks source [ "**" ] [] false abort

            // REVIEW FIX (Codex, PR #15): `restore` had no abort predicate and the
            // dispatcher did no post-copy check, so a large `unstash` as the final step
            // inside a `timeout` finished and reported success past the deadline.
            let mutable aborted = selectionAborted || abort ()
            let mutable problem =
                selectionProblem
                |> Option.map (function
                    | SaveProblem.SelectedPathRefused(relative, _) ->
                        $"unstash refuses stored path ‘{safeDiagnosticPath relative}’: stored symbolic links and linked directory descendants are not restored"
                    | SaveProblem.StorageFailure detail ->
                        $"unstash storage read failed: {detail}")
            let restored = System.Collections.Generic.List<string>()

            for relative in files do
                if not aborted && Option.isNone problem then
                    if abort () then
                        aborted <- true
                    else
                        match Native.openFileWithoutLinks source relative with
                        | Error why ->
                            problem <-
                                Some $"unstash refuses stored path ‘{safeDiagnosticPath relative}’: {why}"
                        | Ok input ->
                            use input = input
                            let sourceMode = Native.fileMode input
                            let sourceModified = Native.fileLastWriteTimeUtc input

                            match Native.createWorkspaceFileWithoutLinks workspace relative with
                            | Error why ->
                                problem <-
                                    Some $"unstash refuses restore path ‘{safeDiagnosticPath relative}’: {why}"
                            | Ok output ->
                                use output = output
                                try
                                    input.CopyTo output
                                    // Content writes may clear setuid/setgid. Apply the
                                    // stored timestamp and then the mode through the
                                    // still-open descriptor, leaving special bits last.
                                    Native.setFileLastWriteTimeUtc output sourceModified
                                    Native.setFileMode output sourceMode
                                    restored.Add relative
                                    if abort () then aborted <- true
                                with ex ->
                                    problem <-
                                        Some $"unstash could not restore ‘{safeDiagnosticPath relative}’ ({ex.GetType().Name})"

            match problem, aborted with
            | _, true -> Error "aborted: the step was interrupted while restoring the stash"
            | Some why, false -> Error why
            | None, false -> Ok(List.ofSeq restored)
