namespace Fogell.Execution

open System
open System.Diagnostics
open System.Threading

type ControllerScmEnvironment = private ControllerScmEnvironment of (string * string) list

module LaunchEnvironment =

    [<Literal>]
    let private FallbackPath = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

    let private ambient name =
        match Environment.GetEnvironmentVariable name with
        | null
        | "" -> None
        | value -> Some(name, value)

    let private selected names = names |> List.choose ambient

    let buildBaseline agentHome =
        [ "PATH", FallbackPath
          "HOME", agentHome
          "TMPDIR", IO.Path.Combine(agentHome, "tmp") ]

    /// Construct an opaque controller-SCM profile from already validated
    /// controller configuration. It cannot be passed to a build launcher.
    let internal controllerScmFrom environment = ControllerScmEnvironment environment

    let internal isExecutableFile path =
        try
            if not (IO.File.Exists path) then
                false
            else
                let mode = IO.File.GetUnixFileMode path
                let executeBits =
                    IO.UnixFileMode.UserExecute
                    ||| IO.UnixFileMode.GroupExecute
                    ||| IO.UnixFileMode.OtherExecute

                mode &&& executeBits <> enum<IO.UnixFileMode> 0
        with _ ->
            false

    let private resolveExecutable
        (executable: string)
        (workingDirectory: string)
        (environment: (string * string) list)
        =
        environment
        |> List.rev
        |> List.tryPick (fun (name, value) -> if name = "PATH" then Some value else None)
        |> Option.bind (fun path ->
            path.Split(IO.Path.PathSeparator, StringSplitOptions.None)
            |> Array.map (fun directory ->
                let root =
                    if String.IsNullOrEmpty directory then
                        workingDirectory
                    elif IO.Path.IsPathRooted directory then
                        directory
                    else
                        IO.Path.Combine(workingDirectory, directory)

                IO.Path.GetFullPath(IO.Path.Combine(root, executable)))
            |> Array.tryFind isExecutableFile)

    let resolveBuildExecutable executable workingDirectory environment =
        resolveExecutable executable workingDirectory environment

    let resolveControllerScmExecutable executable workingDirectory (ControllerScmEnvironment environment) =
        resolveExecutable executable workingDirectory environment

    /// Controller-only SCM launch input. Additional deployment-specific helper
    /// variables may be opted in by name through FOGELL_SCM_ENV_ALLOWLIST; that
    /// control variable is parsed here and is never copied to the child itself.
    let controllerScmBaseline () =
        let standard =
            [ "PATH"
              "HOME"
              "TMPDIR"
              "USER"
              "LOGNAME"
              "XDG_CONFIG_HOME"
              "SSH_AUTH_SOCK"
              "SSH_ASKPASS"
              "GIT_ASKPASS"
              "GIT_SSH"
              "GIT_SSH_COMMAND"
              "GIT_CONFIG_GLOBAL"
              "GIT_CONFIG_SYSTEM"
              "GIT_SSL_CAINFO"
              "SSL_CERT_FILE"
              "SSL_CERT_DIR"
              "HTTP_PROXY"
              "HTTPS_PROXY"
              "ALL_PROXY"
              "NO_PROXY"
              "http_proxy"
              "https_proxy"
              "all_proxy"
              "no_proxy" ]

        let additional =
            match Environment.GetEnvironmentVariable "FOGELL_SCM_ENV_ALLOWLIST" with
            | null
            | "" -> []
            | value ->
                value.Split(',', StringSplitOptions.RemoveEmptyEntries ||| StringSplitOptions.TrimEntries)
                |> Array.toList

        let chosen =
            standard @ additional
            |> List.distinct
            |> selected

        (if chosen |> List.exists (fun (name, _) -> name = "PATH") then
             chosen
         else
             ("PATH", FallbackPath) :: chosen)
        |> controllerScmFrom

    /// Replace ProcessStartInfo's inherited dictionary with exactly the build
    /// map. Last-wins preserves nested overlays.
    let applyBuildTo (startInfo: ProcessStartInfo) (environment: (string * string) list) =
        startInfo.Environment.Clear()

        for key, value in environment do
            startInfo.Environment[key] <- value

    /// Apply controller-only Git transport authority. The opaque argument keeps
    /// ordinary build launch sites from accidentally accepting this profile.
    let applyControllerScmTo (startInfo: ProcessStartInfo) (ControllerScmEnvironment environment) =
        startInfo.Environment.Clear()

        for key, value in environment do
            startInfo.Environment[key] <- value

/// FG-031/FG-032. Process-group lifecycle containment.
///
/// The mechanism: every step is launched through `setsid`, so the child leads a
/// new session and its pid IS its process-group id. Signalling `-pgid` then
/// reaches the step and every descendant it spawned, which is the difference
/// between terminating a step and orphaning its children.
///
/// ADR 0008 is explicit that this is *lifecycle* containment, not a hostile
/// multi-tenant boundary. A determined workload can leave the group with its own
/// `setsid`; untrusted multi-tenant work needs VM-level isolation.
type Outcome =
    | Completed of exitCode: int
    | Signalled of signal: int
    | TimedOut
    | Cancelled

/// Process output crossed Fogell's fixed in-memory safety boundary.  The text is
/// deliberately constant: callers may persist this diagnostic without exposing
/// process output (which can contain credentials).
[<Sealed>]
type OutputLimitExceededException() =
    inherit Exception("process output exceeded Fogell's bounded output limit")

type Termination =
    { /// True when SIGTERM alone was enough — i.e. the step had a chance to
      /// clean up, which is the contract scripts rely on (ADR 0005).
      GracefulExit: bool
      /// True when SIGKILL was needed after the grace period elapsed.
      Escalated: bool
      LeakedProcesses: int }

/// Why [waitForProcessExit] returned — decided ONCE, when the wait ends.
type internal WaitEnd =
    | Waiting
    | Exited
    | Expired
    | Interrupted
    | OutputLimit

type RunResult =
    { Outcome: Outcome
      Stdout: string
      /// Exact token provenance for non-capture stdout which crossed the raw
      /// matcher. None means [Stdout] is raw/unredacted capture output.
      StdoutRedacted: RedactedText option
      /// True only when the stdout reader observed a real EOF. Capture mode may
      /// return a bounded snapshot while an escaped descendant holds the pipe.
      StdoutReachedEof: bool
      Stderr: string
      /// Exact token provenance for stderr which crossed the raw matcher.
      StderrRedacted: RedactedText option
      DurationMs: int64
      ProcessGroupId: int option
      Termination: Termination option
      /// A cleanup step that FAILED — e.g. the secret-bearing shebang script that
      /// could not be deleted. Silence here would leave the file on disk while the
      /// security contract claims cleanup is guaranteed; the caller surfaces this
      /// as an engine note.
      CleanupFailure: string option
      /// The generated durable-script id for THIS run, when a shebang script was
      /// materialised — the caller canonicalises exactly this id, never a shape.
      DurableId: string option }

/// Per-stream credits for process bytes which have crossed the raw matcher but
/// have not yet formed an output record.  [Admit] atomically transfers the
/// supplied consumed input credits into the final redacted record admission;
/// [Release] returns bytes which CRLF normalization, a discarded oversized
/// record, or an aborted reader will never turn into a record.
type BufferedOutputAdmission =
    { Reserve: int -> unit
      Admit: int -> RedactedText -> unit
      Release: int -> unit }

type RedactedAdmission =
    { Admit: RedactedText -> unit
      Buffered: BufferedOutputAdmission option
      /// Ends owner-side output admission without claiming pipe EOF. Used when
      /// ProcessGroup returns after a bounded reader wait while an escaped
      /// writer may still hold the pipe.
      Close: (unit -> unit) option
      Complete: unit -> unit }

type RunRequest =
    { Command: string
      WorkingDirectory: string
      Environment: (string * string) list
      TimeoutMs: int64 option
      /// How long a step may take to honour SIGTERM before it is killed.
      GraceMs: int
      /// Called with each output line as it arrives, so a running build streams
      /// rather than materialising at the end (FG-040 / JB-LOG-002 parity).
      OnLine: (string -> unit) option
      /// Engine-authored narration has not crossed [OutputRedaction]. Keep its
      /// publication provenance separate from process bytes so the caller can
      /// apply its ordinary run-wide mask. None preserves the direct-call API by
      /// falling back to [OnLine].
      OnGeneratedLine: (string -> unit) option
      /// Synchronous trace admission for engine-authored narration. Walker uses
      /// this under the same registration lock as raw matching; its external
      /// transport drains independently.
      OnGeneratedAdmission: (string -> unit) option
      /// Provenance-preserving callback used by Executor/Walker. When absent,
      /// redacted process lines fall back to decoded [OnLine] strings.
      OnRedactedLine: (RedactedText -> unit) option
      /// Synchronous trace admission invoked inside [OutputRedaction]'s lock.
      /// This closes the matcher-to-trace registration window without running
      /// a potentially slow external publisher under that lock.
      OnRedactedAdmission: (RedactedText -> unit) option
      /// Mint independent synchronous admission lifecycles for stdout and
      /// stderr. Completion lets a late-binding publication layer retain an
      /// ambiguous per-stream suffix until real EOF without conflating the two
      /// process pipes. The historical single callback above remains for direct
      /// callers which do not need provenance identity.
      CreateRedactedAdmission: (unit -> RedactedAdmission) option
      /// Reserve captured stdout against an optional run-wide budget before
      /// retaining each decoded chunk. Captured text bypasses log admission.
      ReserveCapturedOutput: (int -> unit) option
      /// FG-236. Opaque raw-output policy. Stdout and stderr each create an
      /// independent matcher before CR/LF framing.
      OutputRedaction: OutputRedactionPolicy option
      SuppressStdoutEcho: bool
      ReapGroup: bool
      Interrupt: (unit -> bool) option
      /// When BOTH the deadline and an interrupt are observable in the same poll,
      /// this decides which event was actually EARLIER — the caller owns the
      /// timestamps (its clock stamps the sibling failure and its deadline), so the
      /// tie cannot be broken here. None means deadline-first, the plain reading.
      InterruptBeatsDeadline: (unit -> bool) option
      /// See [StepRequest.WorkspaceRoot] — where command scaffolding is created.
      WorkspaceRoot: string option }

    static member create(command, workingDirectory) =
        { Command = command
          WorkingDirectory = workingDirectory
          Environment = []
          TimeoutMs = None
          GraceMs = 2_000
          OnLine = None
          OnGeneratedLine = None
          OnGeneratedAdmission = None
          OnRedactedLine = None
          OnRedactedAdmission = None
          CreateRedactedAdmission = None
          ReserveCapturedOutput = None
          OutputRedaction = None
          SuppressStdoutEcho = false
          ReapGroup = true
          Interrupt = None
          InterruptBeatsDeadline = None
          WorkspaceRoot = None }

module ProcessGroup =

    /// Every limit is measured in UTF-16 code units, the unit used by
    /// StreamReader, StringBuilder and RedactedText. A 16 Mi-unit record
    /// preserves established 8 MiB captured stdout workloads while bounding each
    /// retained stream, framed record and callback backlog for one invocation.

    [<Literal>]
    let OutputLimitCharacters = 16 * 1024 * 1024

    [<Literal>]
    let CallbackLimitCount = 1024

    /// [StringBuilder.AppendLine] writes the platform terminator, which is two
    /// UTF-16 code units on CRLF platforms. Keep the capacity calculation
    /// explicit so the advertised bound holds independently of the host OS.
    let internal fitsOutputLine sinkLength lineLength terminatorLength =
        sinkLength >= 0
        && lineLength >= 0
        && terminatorLength >= 0
        && sinkLength <= OutputLimitCharacters
        && lineLength <= OutputLimitCharacters - sinkLength
        && terminatorLength <= OutputLimitCharacters - sinkLength - lineLength

    /// Incremental equivalent of StreamReader.ReadLine: CR, LF and CRLF frame
    /// lines, while EOF publishes a final unterminated non-empty line. Keeping
    /// this after the raw masker is the ordering guarantee FG-236 requires.
    type internal RawLineFramer(publish: int -> string -> unit, release: int -> unit, overflow: unit -> unit) =
        let line = Text.StringBuilder()
        let mutable afterCr = false
        let mutable discarding = false
        let mutable pendingCharacters = 0

        let publishPending value =
            let consumed = pendingCharacters
            pendingCharacters <- 0
            publish consumed value

        let releasePending () =
            if pendingCharacters > 0 then
                let discarded = pendingCharacters
                pendingCharacters <- 0
                release discarded

        member _.Push(text: string) =
            let mutable visited = 0

            try
                for index = 0 to text.Length - 1 do
                    let c = text[index]
                    visited <- index + 1
                    pendingCharacters <- pendingCharacters + 1

                    if afterCr && c = '\n' then
                        afterCr <- false
                        // The preceding CR already completed and transferred the
                        // record. This LF is only CRLF framing state.
                        releasePending ()
                    else
                        afterCr <- false

                        if c = '\r' || c = '\n' then
                            if not discarding then publishPending (line.ToString())
                            else releasePending ()

                            line.Clear() |> ignore
                            discarding <- false
                            afterCr <- c = '\r'
                        else
                            if not discarding then
                                if line.Length = OutputLimitCharacters then
                                    discarding <- true
                                    line.Clear() |> ignore
                                    releasePending ()
                                    overflow ()
                                else
                                    line.Append c |> ignore
                            else
                                // Do not retain run-wide credit for a record this
                                // per-process guard has already discarded.
                                releasePending ()
            with _ ->
                // A synchronous admission can fail after this whole chunk was
                // reserved but before its suffix was visited. Return both the
                // current line and that unvisited suffix exactly once.
                releasePending ()
                let unvisited = text.Length - visited

                if unvisited > 0 then
                    release unvisited

                reraise ()

        member _.Complete() =
            if line.Length > 0 && not discarding then
                publishPending (line.ToString())
                line.Clear() |> ignore
            else
                releasePending ()

        member _.Abandon() =
            line.Clear() |> ignore
            releasePending ()

    /// The same framing grammar with per-character redaction provenance kept
    /// beside every published line.
    type internal RedactedLineFramer(publish: int -> RedactedText -> unit, release: int -> unit, overflow: unit -> unit) =
        let line = RedactedTextBuilder()
        let mutable lineLength = 0
        let mutable afterCr = false
        let mutable discarding = false
        let mutable pendingCharacters = 0

        let publishPending value =
            let consumed = pendingCharacters
            pendingCharacters <- 0
            publish consumed value

        let releasePending () =
            if pendingCharacters > 0 then
                let discarded = pendingCharacters
                pendingCharacters <- 0
                release discarded

        member _.Push(value: RedactedText) =
            let mutable visited = 0

            try
                for index = 0 to value.Text.Length - 1 do
                    let c = value.Text[index]
                    visited <- index + 1
                    pendingCharacters <- pendingCharacters + 1

                    if afterCr && c = '\n' then
                        afterCr <- false
                        // The CR was transferred with the preceding record; this
                        // LF contributes no output record of its own.
                        releasePending ()
                    else
                        afterCr <- false

                        if c = '\r' || c = '\n' then
                            if not discarding then publishPending (line.ToRedactedText())
                            else releasePending ()

                            line.Clear()
                            lineLength <- 0
                            discarding <- false
                            afterCr <- c = '\r'
                        else
                            if not discarding then
                                if lineLength = OutputLimitCharacters then
                                    discarding <- true
                                    line.Clear()
                                    lineLength <- 0
                                    releasePending ()
                                    overflow ()
                                else
                                    if value.TokenCharacters[index] then
                                        line.AppendProtected(string c)
                                    else
                                        line.AppendRaw c

                                    lineLength <- lineLength + 1
                            else
                                releasePending ()
            with _ ->
                // `Reserve` covered the complete transformed chunk. If the
                // final-record admission rejects partway through it, the
                // framer owns and returns only bytes that did not transfer.
                releasePending ()
                let unvisited = value.Text.Length - visited

                if unvisited > 0 then
                    release unvisited

                reraise ()

        member _.Complete() =
            if lineLength > 0 && not discarding then
                publishPending (line.ToRedactedText())
                line.Clear()
                lineLength <- 0
            else
                releasePending ()

        member _.Abandon() =
            line.Clear()
            lineLength <- 0
            releasePending ()

    [<RequireQualifiedAccess>]
    type internal ProcessIdentityState =
        | Matching of char
        | Absent
        | Changed
        | Uncertain

    type internal LinuxProcessStat =
        { State: char
          ParentProcessId: int
          ProcessGroupId: int
          ThreadCount: int
          StartTime: string }

    [<RequireQualifiedAccess>]
    type internal LinuxProcessObservation =
        | Present of LinuxProcessStat
        | Absent
        | Uncertain

    type internal RegisteredGroupIdentity =
        { GroupId: int
          LeaderStartTime: string
          AnchorPid: int
          AnchorStartTime: string }

    let internal parseLinuxProcessStat (value: string) =
        let close = value.LastIndexOf ')'

        if close < 0 || close + 2 >= value.Length then
            None
        else
            let fields =
                value.Substring(close + 2).Split(' ', StringSplitOptions.RemoveEmptyEntries)

            match fields with
            | fields when fields.Length > 19 && fields[0].Length = 1 ->
                match Int32.TryParse fields[1], Int32.TryParse fields[2], Int32.TryParse fields[17] with
                | (true, parentProcessId), (true, processGroupId), (true, threadCount) ->
                    Some
                        { State = fields[0].[0]
                          ParentProcessId = parentProcessId
                          ProcessGroupId = processGroupId
                          ThreadCount = threadCount
                          StartTime = fields[19] }
                | _ -> None
            | _ -> None

    let private observeLinuxProcess pid =
        try
            match IO.File.ReadAllText($"/proc/{pid}/stat") |> parseLinuxProcessStat with
            | Some stat -> LinuxProcessObservation.Present stat
            | None -> LinuxProcessObservation.Uncertain
        with
        | :? IO.FileNotFoundException
        | :? IO.DirectoryNotFoundException -> LinuxProcessObservation.Absent
        | _ -> LinuxProcessObservation.Uncertain

    let internal classifyLiveGroupMembers pgid excludedIdentity observations =
        let mutable live = 0
        let mutable uncertain = false

        for pid, observation in observations do
            let isExcludedIdentity =
                match excludedIdentity, observation with
                | Some(excludedPid, excludedStartTime), LinuxProcessObservation.Present stat ->
                    pid = excludedPid && stat.StartTime = excludedStartTime
                | _ -> false

            if not isExcludedIdentity then
                match observation with
                | LinuxProcessObservation.Present stat when stat.ProcessGroupId = pgid ->
                    if (stat.State = 'Z' || stat.State = 'X' || stat.State = 'x')
                       && stat.ThreadCount <= 1 then
                        ()
                    else
                        // A thread-group leader may be defunct while sibling
                        // threads remain executable; num_threads distinguishes
                        // that live group from a final zombie remnant.
                        live <- live + 1
                | LinuxProcessObservation.Uncertain -> uncertain <- true
                | _ -> ()

        if uncertain then -1 else live

    // All adopted-child waitpid calls share this lock. A PID cannot be reused
    // until its zombie has been reaped; serializing our only reapers therefore
    // keeps the identity/group observation adjacent to the PID-specific wait.
    // Never use waitpid(-1): another concurrent step owns its direct children.
    let private registeredChildReapLock = obj ()

    let internal reapObservedRegisteredMember
        pgid
        candidatePid
        expectedStartTime
        requiredParentPid
        observe
        reap
        =
        lock registeredChildReapLock (fun () ->
            match observe () with
            | LinuxProcessObservation.Present stat
                when stat.ProcessGroupId = pgid
                     && stat.ParentProcessId = requiredParentPid
                     && (expectedStartTime
                         |> Option.forall (fun expected -> stat.StartTime = expected))
                     && (stat.State = 'Z' || stat.State = 'X' || stat.State = 'x')
                     && stat.ThreadCount <= 1 ->
                reap ()
                true
            | _ -> false)

    let internal observeLiveGroupCandidate pgid pid queryGroup observe =
        match queryGroup pid with
        | Native.ProcessGroupQuery.Found group when group = pgid ->
            match observe pid with
            | LinuxProcessObservation.Present stat when stat.ProcessGroupId <> pgid ->
                // Membership changed between getpgid and the stat read. The
                // numeric PID may have been reused, so this scan cannot prove
                // that the original group is empty.
                Some(pid, LinuxProcessObservation.Uncertain)
            | observation -> Some(pid, observation)
        | Native.ProcessGroupQuery.Found _
        | Native.ProcessGroupQuery.Absent -> None
        | Native.ProcessGroupQuery.Uncertain ->
            Some(pid, LinuxProcessObservation.Uncertain)

    let internal scanLiveGroupCandidates pgid pids queryGroup observe =
        let observations = ResizeArray<int * LinuxProcessObservation>()
        let initiallyForeign = ResizeArray<int>()

        let observeMatched pid =
            match observe pid with
            | LinuxProcessObservation.Present stat when stat.ProcessGroupId <> pgid ->
                pid, LinuxProcessObservation.Uncertain
            | observation -> pid, observation

        for pid in pids do
            match queryGroup pid with
            | Native.ProcessGroupQuery.Found group when group = pgid ->
                observations.Add(observeMatched pid)
            | Native.ProcessGroupQuery.Found _ ->
                // A process may join this group after the candidate filter
                // first sees it. Re-query these misses at the scan boundary.
                initiallyForeign.Add pid
            | Native.ProcessGroupQuery.Absent -> ()
            | Native.ProcessGroupQuery.Uncertain ->
                observations.Add(pid, LinuxProcessObservation.Uncertain)

        for pid in initiallyForeign do
            match queryGroup pid with
            | Native.ProcessGroupQuery.Found group when group = pgid ->
                observations.Add(observeMatched pid)
            | Native.ProcessGroupQuery.Found _
            | Native.ProcessGroupQuery.Absent -> ()
            | Native.ProcessGroupQuery.Uncertain ->
                observations.Add(pid, LinuxProcessObservation.Uncertain)

        observations |> Seq.toList

    let private scanLiveGroupMembers pgid excludedIdentity =
        try
            // The wait loops call this repeatedly. Use getpgid as the cheap
            // candidate filter and read stat only for possible members; ESRCH
            // is an ordinary exit race, while every other query failure keeps
            // the whole observation fail-closed.
            IO.Directory.GetDirectories "/proc"
            |> Array.choose (fun directory ->
                match Int32.TryParse(IO.Path.GetFileName directory) with
                | true, pid -> Some pid
                | _ -> None)
            |> fun pids ->
                scanLiveGroupCandidates pgid pids Native.queryProcessGroup observeLinuxProcess
            |> classifyLiveGroupMembers pgid excludedIdentity
        with _ ->
            -1

    let internal signalRegisteredGroup
        (identity: RegisteredGroupIdentity)
        observeLeader
        observeAnchor
        sendGroup
        signal
        =
        let matches expectedStartTime = function
            | LinuxProcessObservation.Present stat ->
                stat.StartTime = expectedStartTime
                && stat.ProcessGroupId = identity.GroupId
                && not ((stat.State = 'Z' || stat.State = 'X' || stat.State = 'x') && stat.ThreadCount <= 1)
            | _ -> false

        if matches identity.AnchorStartTime (observeAnchor ())
           || matches identity.LeaderStartTime (observeLeader ()) then
            sendGroup signal
        else
            false

    let internal signalRegisteredAnchor
        (identity: RegisteredGroupIdentity)
        observeAnchor
        sendAnchor
        signal
        =
        match observeAnchor () with
        | LinuxProcessObservation.Present stat
            when stat.StartTime = identity.AnchorStartTime
                 && stat.ProcessGroupId = identity.GroupId
                 && not ((stat.State = 'Z' || stat.State = 'X' || stat.State = 'x') && stat.ThreadCount <= 1) ->
            sendAnchor signal
        | _ -> false

    let internal attemptEscalation exitedOnTerm sendKill waitAfterKill =
        if exitedOnTerm then
            false
        else
            let delivered = sendKill ()

            if delivered then
                waitAfterKill ()

            delivered

    let internal deliverOrObserveExtinction sendSignal observeExtinct =
        sendSignal () || observeExtinct ()

    /// The marker write happens before the child stops itself. A SIGCONT sent
    /// merely because the marker arrived can therefore be lost while the child
    /// is still running, after which it executes SIGSTOP and wedges forever.
    /// Wait for the identity-bound /proc state transition under one strict bound.
    let internal waitForIdentityStop
        maxRunningChecks
        (observe: unit -> ProcessIdentityState)
        (pause: unit -> unit)
        =
        if maxRunningChecks < 0 then
            invalidArg (nameof maxRunningChecks) "running-state check count cannot be negative"

        let rec wait remaining =
            match observe () with
            | ProcessIdentityState.Matching('T' | 't') -> true
            | ProcessIdentityState.Matching _ when remaining > 0 ->
                pause ()
                wait (remaining - 1)
            | _ -> false

        wait maxRunningChecks

    [<RequireQualifiedAccess>]
    type internal LauncherFormationState =
        | SameIdentity of processGroup: int
        | Absent
        | Changed
        | Uncertain

    [<RequireQualifiedAccess>]
    type internal LauncherFormationDecision =
        | GroupFormed
        | Disappeared
        | TerminateLauncher
        | Refused

    /// The EOF guard can wake after fork but before the child has executed
    /// `setsid`. Its numeric pid is not yet a safe negative-pgid signal target at
    /// that instant. Keep the SAME start-time-bound identity under observation
    /// until it becomes its own group, disappears, or the bounded proof fails.
    /// The out-of-process shell guard below mirrors this decision table because
    /// it must survive the managed owner being SIGKILLed.
    let internal waitForIdentityGroup
        pid
        maxPendingChecks
        (observe: unit -> LauncherFormationState)
        (pause: unit -> unit)
        =
        if maxPendingChecks < 0 then
            invalidArg (nameof maxPendingChecks) "pending-state check count cannot be negative"

        let rec wait remaining =
            match observe () with
            | LauncherFormationState.SameIdentity processGroup when processGroup = pid ->
                LauncherFormationDecision.GroupFormed
            | LauncherFormationState.SameIdentity _ when remaining > 0 ->
                pause ()
                wait (remaining - 1)
            | LauncherFormationState.SameIdentity _ ->
                LauncherFormationDecision.TerminateLauncher
            | LauncherFormationState.Absent -> LauncherFormationDecision.Disappeared
            | _ -> LauncherFormationDecision.Refused

        wait maxPendingChecks

    /// Count processes still in the group. Reads /proc directly rather than
    /// shelling out, so the check cannot itself spawn something.
    /// -1 means UNKNOWN: the /proc read itself failed. FG-103 — returning 0 there
    /// made the leak check a gate that could not fail: a broken /proc reported
    /// "nothing survived" while FG-032's headline claim rested on this number, and
    /// both unit tests asserting 0 passed against a completely dead reader.
    /// Unknown fails CLOSED everywhere downstream: the group is treated as still
    /// populated, and the diagnostic says the check was unavailable rather than
    /// inventing a clean bill.
    let private survivorsIn (pgid: int) : int = scanLiveGroupMembers pgid None

    /// Wait until the group is EMPTY, up to `budgetMs`.
    let private waitForGroupExit (pgid: int) (budgetMs: int) : bool =
        let sw = Stopwatch.StartNew()
        let mutable gone = survivorsIn pgid = 0

        while not gone && sw.ElapsedMilliseconds < int64 budgetMs do
            Thread.Sleep 20
            gone <- survivorsIn pgid = 0

        gone

    let private survivorsInExceptAnchor (identity: RegisteredGroupIdentity) : int =
        scanLiveGroupMembers
            identity.GroupId
            (Some(identity.AnchorPid, identity.AnchorStartTime))

    let private waitForGroupExitExceptAnchor identity budgetMs =
        let sw = Stopwatch.StartNew()
        let mutable gone = survivorsInExceptAnchor identity = 0

        while not gone && sw.ElapsedMilliseconds < int64 budgetMs do
            Thread.Sleep 20
            gone <- survivorsInExceptAnchor identity = 0

        gone

    let private waitForRegisteredGroupExit identity budgetMs =
        let sw = Stopwatch.StartNew()

        let reapKnownGroupChildren () =
            try
                IO.Directory.GetDirectories "/proc"
                |> Array.iter (fun directory ->
                    match Int32.TryParse(IO.Path.GetFileName directory) with
                    | true, pid ->
                        match Native.queryProcessGroup pid with
                        | Native.ProcessGroupQuery.Found group when group = identity.GroupId ->
                            // PR_SET_CHILD_SUBREAPER makes orphaned group
                            // members our children. Revalidate membership under
                            // the shared reaper lock before PID-specific waitpid,
                            // so an already-reaped/reused PID from a concurrent
                            // step cannot have its exit status stolen.
                            reapObservedRegisteredMember
                                identity.GroupId
                                pid
                                None
                                Environment.ProcessId
                                (fun () -> observeLinuxProcess pid)
                                (fun () -> Native.tryReapChild pid |> ignore)
                            |> ignore
                        | _ -> ()
                    | _ -> ())
            with _ -> ()

        let rec wait () =
            // Once the session leader exits, PR_SET_CHILD_SUBREAPER reparents
            // its orphaned group members to Run.Host. Reap every adopted PID
            // observed in this registered group; PID-specific waitpid never
            // harvests an unrelated step. The following group ESRCH is the
            // atomic boundary: while the numeric group exists, a same-session
            // process can still join it.
            reapKnownGroupChildren ()

            match Native.probeProcessGroup identity.GroupId with
            | Native.ProcessGroupPresence.Absent -> true
            | _ when sw.ElapsedMilliseconds < int64 budgetMs ->
                Thread.Sleep 20
                wait ()
            | _ -> false

        wait ()

    let private registeredGroupLeakCount identity =
        match Native.probeProcessGroup identity.GroupId with
        | Native.ProcessGroupPresence.Absent -> 0
        | _ ->
            match survivorsIn identity.GroupId with
            | count when count > 0 -> count
            | _ -> -1

    let private releaseIdentityAnchor identity =
        // The anchor is SIGSTOPped before registration. TERM remains pending
        // while stopped, so CONT lets it take the default TERM action without
        // introducing another long-lived helper or inherited descriptor.
        reapObservedRegisteredMember
            identity.GroupId
            identity.AnchorPid
            (Some identity.AnchorStartTime)
            Environment.ProcessId
            (fun () -> observeLinuxProcess identity.AnchorPid)
            (fun () -> Native.tryReapChild identity.AnchorPid |> ignore)
        |> ignore

        if Native.probeProcessGroup identity.GroupId = Native.ProcessGroupPresence.Absent then
            true
        else
            let extinct () =
                Native.probeProcessGroup identity.GroupId = Native.ProcessGroupPresence.Absent

            let termDeliveredOrGone =
                deliverOrObserveExtinction
                    (fun () ->
                        signalRegisteredAnchor
                            identity
                            (fun () -> observeLinuxProcess identity.AnchorPid)
                            (fun signal -> Native.signalProcess identity.AnchorPid signal)
                            Native.SIGTERM)
                    extinct

            if not termDeliveredOrGone then
                false
            elif extinct () then
                true
            else
                deliverOrObserveExtinction
                    (fun () ->
                        signalRegisteredAnchor
                            identity
                            (fun () -> observeLinuxProcess identity.AnchorPid)
                            (fun signal -> Native.signalProcess identity.AnchorPid signal)
                            Native.SIGCONT)
                    extinct
                && waitForRegisteredGroupExit identity 2_000

    let private terminateGroupWithAnchor identity graceMs =
        let sendGroup signal =
            signalRegisteredGroup
                identity
                (fun () -> observeLinuxProcess identity.GroupId)
                (fun () -> observeLinuxProcess identity.AnchorPid)
                (fun signum -> Native.signalGroup identity.GroupId signum)
                signal

        let termDelivered = sendGroup Native.SIGTERM
        let usersExited =
            termDelivered && waitForGroupExitExceptAnchor identity graceMs
        let exitedOnTerm = usersExited && releaseIdentityAnchor identity

        let escalated =
            attemptEscalation
                exitedOnTerm
                (fun () -> sendGroup Native.SIGKILL)
                (fun () -> waitForRegisteredGroupExit identity 2_000 |> ignore)

        { GracefulExit = exitedOnTerm
          Escalated = escalated
          LeakedProcesses = registeredGroupLeakCount identity }

    let private reapWithAnchor identity graceMs =
        if survivorsInExceptAnchor identity = 0
           && releaseIdentityAnchor identity then
            { GracefulExit = true
              Escalated = false
              LeakedProcesses = 0 }
        else
            terminateGroupWithAnchor identity graceMs

    let terminateGroup (pgid: int) (graceMs: int) : Termination =
        let termDelivered = Native.signalGroup pgid Native.SIGTERM
        let exitedOnTerm = termDelivered && waitForGroupExit pgid graceMs

        let escalated =
            if exitedOnTerm then
                false
            else
                Native.signalGroup pgid Native.SIGKILL |> ignore
                waitForGroupExit pgid 2_000 |> ignore
                true

        { GracefulExit = exitedOnTerm
          Escalated = escalated
          LeakedProcesses = survivorsIn pgid }

    let reap (pgid: int) (graceMs: int) : Termination =
        if survivorsIn pgid = 0 then
            { GracefulExit = true
              Escalated = false
              LeakedProcesses = 0 }
        else
            terminateGroup pgid graceMs

    /// Residual quiet sampling used only before an abort signal. The caller owns
    /// the clock so time already spent draining active callbacks consumes this
    /// SAME budget. Keeping the sleeper injectable makes the exact upper bound a
    /// deterministic law rather than a wall-clock assertion in the test suite.
    let internal settleOutputUntilQuiet
        (budgetMs: int)
        (elapsedMilliseconds: unit -> int64)
        (sleep: int -> unit)
        (snapshot: unit -> int * int)
        =
        let requiredQuietSamples = 2

        if elapsedMilliseconds () < int64 budgetMs then
            let mutable previous = snapshot ()
            let mutable consecutiveQuietSamples = 0

            while
                consecutiveQuietSamples < requiredQuietSamples
                && elapsedMilliseconds () < int64 budgetMs do
                let remaining = max 0L (int64 budgetMs - elapsedMilliseconds ())
                let sleepMs = int (min 40L remaining)

                if sleepMs > 0 then
                    sleep sleepMs

                let current = snapshot ()

                if current = previous then
                    consecutiveQuietSamples <- consecutiveQuietSamples + 1
                else
                    consecutiveQuietSamples <- 0

                previous <- current

    let internal preCaptureFallbackScript =
        "wait \"$fogell_inner\" 2>/dev/null || true; exit 125; "

    /// Run one command in its own process group.
    let run (request: RunRequest) : RunResult =
        let sw = Stopwatch.StartNew()

        let containmentDirectory =
            match Environment.GetEnvironmentVariable "FOGELL_PROCESS_GROUP_REGISTRY" with
            | null
            | "" -> None
            | value when OperatingSystem.IsLinux() -> Some(IO.Path.GetFullPath value)
            | _ -> invalidOp "process-group registry containment is supported only on Linux"

        let processStateAndStartTime pid =
            match observeLinuxProcess pid with
            | LinuxProcessObservation.Present stat ->
                ProcessIdentityState.Matching stat.State, Some stat.StartTime
            | LinuxProcessObservation.Absent -> ProcessIdentityState.Absent, None
            | LinuxProcessObservation.Uncertain -> ProcessIdentityState.Uncertain, None

        let observeIdentity pid expectedStartTime =
            match processStateAndStartTime pid with
            | ProcessIdentityState.Matching state, Some actual when actual = expectedStartTime ->
                ProcessIdentityState.Matching state
            | ProcessIdentityState.Matching _, Some _ -> ProcessIdentityState.Changed
            | observation, _ -> observation

        let groupRecordPath pgid =
            containmentDirectory
            |> Option.map (fun directory -> IO.Path.Combine(directory, $"{pgid}.group"))

        let persistGroup pgid startTime anchor anchorStartTime =
            match containmentDirectory with
            | None -> ()
            | Some directory ->
                IO.Directory.CreateDirectory directory |> ignore
                let target = IO.Path.Combine(directory, $"{pgid}.group")
                let temporary = target + $".{Guid.NewGuid():N}.tmp"
                IO.File.WriteAllText(temporary, $"{pgid} {startTime} {anchor} {anchorStartTime}\n")
                IO.File.Move(temporary, target)

        let forgetExtinguishedGroup pgid =
            if Native.probeProcessGroup pgid = Native.ProcessGroupPresence.Absent then
                groupRecordPath pgid
                |> Option.iter (fun path ->
                    try IO.File.Delete path with _ -> ())

        // `setsid --wait` keeps a parent around to collect the exit status, but
        // that parent is what .NET reports as the process id — and ITS group is
        // ours, not the child's. So the session leader reports its own pid on
        // stderr as the first line, and that is the real process-group id.
        let pgidMarker = "__FOGELL_PGID "

        let launcherIdentityPath =
            IO.Path.Combine(IO.Path.GetTempPath(), $"fogell-launch-{Guid.NewGuid():N}.identity")

        use _launcherIdentityCleanup =
            { new IDisposable with
                member _.Dispose() =
                    for path in [ launcherIdentityPath; launcherIdentityPath + ".tmp" ] do
                        try IO.File.Delete path with _ -> () }

        let psi = ProcessStartInfo("/bin/sh")
        // Keep an explicit wait-status-preserving parent outside the new group.
        // This makes marker provenance observable (proc.Id is the outer waiter,
        // not the session leader) without `setsid --fork --wait`: util-linux maps
        // a signal-killed child to the bare signal number, whereas the shell's
        // wait status preserves the established 128+signal diagnostic contract.
        // fd 9 explicitly carries the controller-owned liveness pipe into the
        // async guard: POSIX shells otherwise replace an asynchronous command's
        // stdin with /dev/null. The inner session closes it before user code, so
        // only Run.Host can keep the guard armed.
        psi.ArgumentList.Add "-c"
        psi.ArgumentList.Add(
            "fogell_payload=$1; fogell_inner_argv0=$2; fogell_inner_argv1=$3; "
            + "fogell_registry=$4; fogell_launch_gate=$5; fogell_launch_ready=$6; fogell_guard_observed=$7; "
            + "fogell_guard_stopped=$8; fogell_cleanup_release=$9; "
            + "fogell_watchdog_term_file=${10}; fogell_watchdog_kill_release=${11}; "
            + "fogell_launcher_identity=${12}; exec 9<&0; "
            + "(if ! IFS= read -r fogell_self_stat < /proc/self/stat; then exit 125; fi; "
            + "fogell_self_pid=${fogell_self_stat%% *}; fogell_self_tail=${fogell_self_stat##*) }; set -- $fogell_self_tail; "
            + "if [ \"$#\" -le 19 ]; then exit 125; fi; shift 19; fogell_self_start=$1; "
            + "if ! printf '%s %s\\n' \"$fogell_self_pid\" \"$fogell_self_start\" > \"$fogell_launcher_identity.tmp\" "
            + "|| ! /bin/mv \"$fogell_launcher_identity.tmp\" \"$fogell_launcher_identity\"; then exit 125; fi; "
            + "if [ -n \"$fogell_launch_gate\" ]; then while [ ! -e \"$fogell_launch_gate\" ]; do /bin/sleep 0.01; done; fi; "
            + "exec /usr/bin/setsid /bin/sh -c \"$fogell_payload\" \"$fogell_inner_argv0\" \"$fogell_inner_argv1\" \"$fogell_registry\" 9<&- </dev/null) & "
            + "fogell_inner=$!; "
            + "fogell_launcher_start=; fogell_capture_checks=200; "
            + "while [ -z \"$fogell_launcher_start\" ] && [ \"$fogell_capture_checks\" -ge 0 ]; do "
            + "if [ -r \"$fogell_launcher_identity\" ] "
            + "&& IFS=' ' read -r fogell_identity_pid fogell_identity_start < \"$fogell_launcher_identity\" "
            + "&& [ \"$fogell_identity_pid\" = \"$fogell_inner\" ] && [ -n \"$fogell_identity_start\" ]; then "
            + "fogell_launcher_start=$fogell_identity_start; "
            + "elif [ ! -e \"/proc/$fogell_inner\" ]; then break; fi; "
            + "if [ -z \"$fogell_launcher_start\" ]; then fogell_capture_checks=$((fogell_capture_checks - 1)); /bin/sleep 0.01; fi; "
            + "done; "
            + "/bin/rm -f \"$fogell_launcher_identity\" \"$fogell_launcher_identity.tmp\"; "
            + "if [ -z \"$fogell_launcher_start\" ]; then "
            // Without the child-published start ticks there is no authority to
            // signal either the numeric PID or its same-number group. Waiting
            // through the shell job table cannot hit a reused process.
            + preCaptureFallbackScript
            + "fi; "
            + "(trap '' HUP INT TERM; "
            + "if ! IFS= read -r fogell_guard_command || [ \"$fogell_guard_command\" != disarm ]; then "
            + "fogell_record=\"$fogell_registry/$fogell_inner.group\"; fogell_safe=0; fogell_kill_launcher=0; "
            + "if [ -n \"$fogell_registry\" ] && [ -r \"$fogell_record\" ] "
            + "&& IFS=' ' read -r fogell_record_pgid fogell_leader_start fogell_anchor fogell_anchor_start < \"$fogell_record\" "
            + "&& [ \"$fogell_record_pgid\" = \"$fogell_inner\" ] && [ \"$fogell_anchor\" -gt 1 ] 2>/dev/null "
            + "&& [ -r \"/proc/$fogell_anchor/stat\" ]; then "
            + "fogell_stat=$(/bin/cat \"/proc/$fogell_anchor/stat\" 2>/dev/null) || fogell_stat=; "
            + "fogell_tail=${fogell_stat##*) }; set -- $fogell_tail; "
            + "if [ \"$3\" = \"$fogell_inner\" ]; then shift 19; [ \"$1\" = \"$fogell_anchor_start\" ] && fogell_safe=1; fi; "
            + "elif [ -n \"$fogell_launcher_start\" ]; then "
            + "fogell_checks=200; fogell_polling=1; "
            + "while [ \"$fogell_polling\" -eq 1 ]; do "
            + "if [ ! -r \"/proc/$fogell_inner/stat\" ] || ! IFS= read -r fogell_stat < \"/proc/$fogell_inner/stat\"; then break; fi; "
            + "fogell_tail=${fogell_stat##*) }; set -- $fogell_tail; "
            + "if [ \"$#\" -le 19 ]; then break; fi; "
            + "fogell_pgrp=$3; shift 19; fogell_actual_start=$1; "
            + "if [ \"$fogell_actual_start\" != \"$fogell_launcher_start\" ]; then break; fi; "
            + "if [ \"$fogell_pgrp\" = \"$fogell_inner\" ]; then fogell_safe=1; break; fi; "
            + "if [ -n \"$fogell_guard_observed\" ]; then printf observed > \"$fogell_guard_observed\"; fogell_guard_observed=; fi; "
            + "if [ \"$fogell_checks\" -le 0 ]; then "
            + "if /bin/kill -STOP \"$fogell_inner\" 2>/dev/null; then "
            + "fogell_stop_checks=200; "
            + "while [ \"$fogell_stop_checks\" -ge 0 ]; do "
            + "if [ ! -r \"/proc/$fogell_inner/stat\" ] || ! IFS= read -r fogell_frozen_stat < \"/proc/$fogell_inner/stat\"; then break; fi; "
            + "fogell_frozen_tail=${fogell_frozen_stat##*) }; set -- $fogell_frozen_tail; "
            + "if [ \"$#\" -le 19 ]; then break; fi; "
            + "fogell_frozen_state=$1; fogell_frozen_pgrp=$3; shift 19; fogell_frozen_start=$1; "
            + "if [ \"$fogell_frozen_start\" != \"$fogell_launcher_start\" ]; then break; fi; "
            + "if [ \"$fogell_frozen_state\" = T ] || [ \"$fogell_frozen_state\" = t ]; then "
            + "if [ \"$fogell_frozen_pgrp\" = \"$fogell_inner\" ]; then fogell_safe=1; else fogell_kill_launcher=1; fi; "
            + "if [ -n \"$fogell_guard_stopped\" ]; then printf '%s' \"$fogell_frozen_pgrp\" > \"$fogell_guard_stopped\"; fi; "
            + "if [ -n \"$fogell_cleanup_release\" ]; then while [ ! -e \"$fogell_cleanup_release\" ]; do /bin/sleep 0.01; done; fi; "
            + "break; fi; "
            + "fogell_stop_checks=$((fogell_stop_checks - 1)); /bin/sleep 0.01; "
            + "done; fi; break; fi; "
            + "fogell_checks=$((fogell_checks - 1)); /bin/sleep 0.01; "
            + "done; "
            + "fi; "
            + "fogell_identity_matches() { "
            + "fogell_check_pid=$1; fogell_check_start=$2; "
            + "[ \"$fogell_check_pid\" -gt 1 ] 2>/dev/null && [ -n \"$fogell_check_start\" ] "
            + "&& [ -r \"/proc/$fogell_check_pid/stat\" ] || return 1; "
            + "fogell_check_stat=$(/bin/cat \"/proc/$fogell_check_pid/stat\" 2>/dev/null) || return 1; "
            + "fogell_check_tail=${fogell_check_stat##*) }; set -- $fogell_check_tail; "
            + "[ \"$#\" -gt 19 ] && [ \"$3\" = \"$fogell_inner\" ] || return 1; "
            // POSIX shells parse `$18` as `${1}8`. Braces are required here:
            // field 20 is the thread count, and a Z/X/x group leader with live
            // sibling threads must remain signal-authorizing evidence.
            + "fogell_check_state=$1; fogell_check_threads=${18}; shift 19; "
            + "[ \"$1\" = \"$fogell_check_start\" ] "
            + "&& { [ \"$fogell_check_state\" != Z ] && [ \"$fogell_check_state\" != X ] "
            + "&& [ \"$fogell_check_state\" != x ] || [ \"$fogell_check_threads\" -gt 1 ] 2>/dev/null; }; "
            + "}; "
            + "fogell_group_authorized() { "
            + "fogell_identity_matches \"${fogell_anchor:-0}\" \"${fogell_anchor_start:-}\" "
            + "|| fogell_identity_matches \"$fogell_inner\" \"${fogell_leader_start:-$fogell_launcher_start}\"; "
            + "}; "
            + "fogell_launcher_authorized() { "
            + "[ \"$fogell_inner\" -gt 1 ] 2>/dev/null && [ -n \"$fogell_launcher_start\" ] "
            + "&& [ -r \"/proc/$fogell_inner/stat\" ] || return 1; "
            + "fogell_launcher_stat=$(/bin/cat \"/proc/$fogell_inner/stat\" 2>/dev/null) || return 1; "
            + "fogell_launcher_tail=${fogell_launcher_stat##*) }; set -- $fogell_launcher_tail; "
            + "[ \"$#\" -gt 19 ] || return 1; fogell_launcher_state=$1; shift 19; "
            + "[ \"$1\" = \"$fogell_launcher_start\" ] "
            + "&& { [ \"$fogell_launcher_state\" = T ] || [ \"$fogell_launcher_state\" = t ]; }; "
            + "}; "
            // This watchdog inherits the build environment, including PATH.
            // Keep every cleanup executable absolute: if a trusted Linux
            // utility is unavailable the shell advances immediately to the
            // next signal instead of letting build-controlled code delay KILL.
            + "if [ \"$fogell_safe\" -eq 1 ]; then "
            + "if fogell_group_authorized; then /bin/kill -TERM -- -$fogell_inner 2>/dev/null || true; "
            + "if [ -n \"$fogell_watchdog_term_file\" ]; then printf term > \"$fogell_watchdog_term_file\"; fi; "
            + "if [ -n \"$fogell_watchdog_kill_release\" ]; then while [ ! -e \"$fogell_watchdog_kill_release\" ]; do /bin/sleep 0.01; done; fi; "
            + "fi; /bin/sleep 0.2; "
            + "if fogell_group_authorized; then /bin/kill -KILL -- -$fogell_inner 2>/dev/null || true; fi; /bin/sleep 0.2; "
            + "elif [ \"$fogell_kill_launcher\" -eq 1 ] && fogell_launcher_authorized; then "
            + "/bin/kill -KILL \"$fogell_inner\" 2>/dev/null || true; /bin/sleep 0.2; "
            + "fi; "
            + "fi) <&9 >/dev/null 2>&1 & fogell_guard=$!; "
            + "if [ -n \"$fogell_launch_ready\" ]; then printf '%s' \"$fogell_inner\" > \"$fogell_launch_ready\"; fi; "
            + "exec 9<&-; "
            + "wait $fogell_inner; fogell_rc=$?; "
            + "exit $fogell_rc")
        psi.ArgumentList.Add "fogell-wait-wrapper" // $0 for the outer waiter
        let mutable mintedDurableId: string option = None

        let shebangFile =
            if true then // EVERY script materialises — see the wrapper comment
                let root =
                    let r = defaultArg request.WorkspaceRoot request.WorkingDirectory
                    // trim only REDUNDANT separators: "/" must stay the filesystem
                    // root, not become "" and turn the whole path relative
                    if r.Length > 1 then r.TrimEnd '/' else r
                let hex = Guid.NewGuid().ToString("N").Substring(0, 8)
                mintedDurableId <- Some hex
                let tmpDir = IO.Path.Combine(root + ".fogell-tmp", $"command-{hex}")

                IO.Directory.CreateDirectory tmpDir |> ignore
                let f = IO.Path.Combine(tmpDir, "command.sh")

                let mode =
                    if request.Command.StartsWith "#!" then
                        IO.UnixFileMode.UserRead ||| IO.UnixFileMode.UserWrite ||| IO.UnixFileMode.UserExecute
                    else
                        IO.UnixFileMode.UserRead ||| IO.UnixFileMode.UserWrite

                // Both files are created owner-only from the first byte with the
                // same mode; the copy is written from the same text rather than
                // `cp`'d, which is the same bytes and the same mode without a
                // window in which the copy exists with a wider one.
                let writeOwnerOnly (path: string) =
                    use stream = IO.File.Open(path, IO.FileStreamOptions(Mode = IO.FileMode.CreateNew, Access = IO.FileAccess.Write, UnixCreateMode = mode))
                    use writer = new IO.StreamWriter(stream)
                    writer.Write request.Command

                try
                    writeOwnerOnly f
                    Some f
                with e ->
                    // a partial secret-bearing file must not outlive a failed write —
                    // the cleanup disposable is registered only after creation succeeds
                    (try IO.File.Delete f with _ -> ())
                    raise e
            else
                None

        // Deletion is attempted on the normal path with the failure CAPTURED (it
        // becomes an engine note); the disposable is the exception-path backstop,
        // where the run is already failing loudly.
        let mutable cleanupFailure: string option = None

        let deleteShebang (f: string) =
            try
                if IO.File.Exists f then IO.File.Delete f
                let d = IO.Path.GetDirectoryName f
                if IO.Directory.Exists d then IO.Directory.Delete(d, false)
            with e ->
                cleanupFailure <- Some $"could not delete shebang script {f}: {e.Message}"

        use _cleanupShebang =
            { new IDisposable with
                member _.Dispose() = shebangFile |> Option.iter deleteShebang }

        let mergeStderr = if request.SuppressStdoutEcho then "" else " 2>&1"
        let registeredPrelude =
            "fogell_anchor=0; "
            + "if [ -n \"$2\" ]; then /bin/sleep 2147483647 </dev/null >/dev/null 2>&1 & fogell_anchor=$!; kill -STOP \"$fogell_anchor\"; fi; "
            + $"printf '%%s%%s %%s\n' '{pgidMarker}' \"$$\" \"$fogell_anchor\" >&2; kill -STOP \"$$\"; "

        (match request.Command.StartsWith "#!" with
         | true ->
             psi.ArgumentList.Add
                 $"{registeredPrelude}exec \"$1\"{mergeStderr}"
         | false ->
             psi.ArgumentList.Add
                 $"{registeredPrelude}exec /bin/sh -xe \"$1\"{mergeStderr}")

        // These are $1..$4 of the outer waiter, and therefore command/$0/$1/$2
        // of the inner shell launched by setsid.
        psi.ArgumentList.Add "fogell-launcher"
        psi.ArgumentList.Add(defaultArg shebangFile request.Command)
        psi.ArgumentList.Add(defaultArg containmentDirectory "")
        // Test-only controller seams. They are read before the child environment
        // is cleared and travel positionally, so a build cannot set them through
        // pipeline environment values. Production leaves all of them empty.
        psi.ArgumentList.Add(defaultArg (Option.ofObj (Environment.GetEnvironmentVariable "FOGELL_TEST_PRE_SETSID_RELEASE_FILE")) "")
        psi.ArgumentList.Add(defaultArg (Option.ofObj (Environment.GetEnvironmentVariable "FOGELL_TEST_PRE_SETSID_READY_FILE")) "")
        psi.ArgumentList.Add(defaultArg (Option.ofObj (Environment.GetEnvironmentVariable "FOGELL_TEST_PRE_SETSID_OBSERVED_FILE")) "")
        psi.ArgumentList.Add(defaultArg (Option.ofObj (Environment.GetEnvironmentVariable "FOGELL_TEST_PRE_SETSID_STOPPED_FILE")) "")
        psi.ArgumentList.Add(defaultArg (Option.ofObj (Environment.GetEnvironmentVariable "FOGELL_TEST_PRE_SETSID_CLEANUP_RELEASE_FILE")) "")
        psi.ArgumentList.Add(defaultArg (Option.ofObj (Environment.GetEnvironmentVariable "FOGELL_TEST_WATCHDOG_TERM_FILE")) "")
        psi.ArgumentList.Add(defaultArg (Option.ofObj (Environment.GetEnvironmentVariable "FOGELL_TEST_WATCHDOG_KILL_RELEASE_FILE")) "")
        psi.ArgumentList.Add launcherIdentityPath

        psi.WorkingDirectory <- request.WorkingDirectory
        psi.RedirectStandardOutput <- true
        psi.RedirectStandardError <- true
        psi.RedirectStandardInput <- true
        psi.UseShellExecute <- false

        LaunchEnvironment.applyBuildTo psi request.Environment

        match containmentDirectory with
        | Some _ when not (Native.enableChildSubreaper ()) ->
            invalidOp "could not establish Linux child-subreaper ownership for process-group anchors"
        | _ -> ()

        use proc = new Process()
        proc.StartInfo <- psi
        proc.EnableRaisingEvents <- true

        let stdout = Text.StringBuilder()
        let stderr = Text.StringBuilder()
        let stdoutRedacted = RedactedTextBuilder()
        let stderrRedacted = RedactedTextBuilder()
        let outputFailureGate = obj ()
        let outputLimitReached =
            Tasks.TaskCompletionSource<unit>(Tasks.TaskCreationOptions.RunContinuationsAsynchronously)
        let mutable outputFailure: exn option = None
        let reportOutputFailure error =
            lock outputFailureGate (fun () ->
                if outputFailure.IsNone then
                    outputFailure <- Some error
                    outputLimitReached.TrySetResult(()) |> ignore)

        let reportOutputLimit () = reportOutputFailure (OutputLimitExceededException())

        let hasOutputFailure () = lock outputFailureGate (fun () -> outputFailure.IsSome)
        let completionOptions = Tasks.TaskCreationOptions.RunContinuationsAsynchronously
        let reportedPgid = Tasks.TaskCompletionSource<int * int>(completionOptions)
        let stdoutClosed = Tasks.TaskCompletionSource<unit>(completionOptions)
        let stderrClosed = Tasks.TaskCompletionSource<unit>(completionOptions)
        let processExited = Tasks.TaskCompletionSource<unit>(completionOptions)
        let stdoutCallbackGate = obj ()
        let stderrCallbackGate = obj ()
        let lineCallbackGate = obj ()
        let mutable lineCallbackTail: Tasks.Task = Tasks.Task.CompletedTask
        let mutable lineCallbacksOpen = true
        let mutable queuedCallbackCharacters = 0
        let mutable queuedCallbackCount = 0

        proc.Exited.Add(fun _ -> processExited.TrySetResult(()) |> ignore)

        let enqueueAction characters action =
            match action with
            | None -> ()
            | Some callback ->
                lock lineCallbackGate (fun () ->
                    if lineCallbacksOpen then
                        if queuedCallbackCount >= CallbackLimitCount
                           || characters > OutputLimitCharacters - queuedCallbackCharacters then
                            reportOutputLimit ()
                        else
                            queuedCallbackCount <- queuedCallbackCount + 1
                            queuedCallbackCharacters <- queuedCallbackCharacters + characters
                            // The reader invokes this callback path serially. Running a
                            // hostile user callback there would prevent an
                            // already-written following line from reaching the buffer and
                            // makes the pre-signal snapshot misclassify it. Keep delivery
                            // serialized, but move it onto an asynchronous continuation so
                            // reader ingestion and EOF can advance independently. This is
                            // deliberately within the successful reservation branch: an
                            // rejected callback must neither run nor release capacity it
                            // never acquired.
                            lineCallbackTail <-
                                lineCallbackTail.ContinueWith(
                                    Action<Tasks.Task>(fun previous ->
                                        try
                                            // Keep a failed output sink sticky. Awaiting only
                                            // the final continuation is sufficient because
                                            // every successor first propagates its antecedent.
                                            previous.GetAwaiter().GetResult()
                                            callback ()
                                        finally
                                            lock lineCallbackGate (fun () ->
                                                queuedCallbackCount <- queuedCallbackCount - 1
                                                queuedCallbackCharacters <- queuedCallbackCharacters - characters)),
                                    CancellationToken.None,
                                    Tasks.TaskContinuationOptions.None,
                                    Tasks.TaskScheduler.Default))

        let enqueueLine (callback: (string -> unit) option) (line: string) =
            enqueueAction line.Length (callback |> Option.map (fun publish -> fun () -> publish line))

        let publishLine line = enqueueLine request.OnLine line

        let publishRedactedLine admission consumedBufferedCharacters line =
            match admission, request.OnRedactedAdmission, request.OnRedactedLine with
            | Some stream, _, _ ->
                match consumedBufferedCharacters, stream.Buffered with
                | Some consumed, Some buffered -> buffered.Admit consumed line
                | _ -> stream.Admit line
            | None, Some admit, _ -> admit line
            | None, None, Some publish -> enqueueAction line.Text.Length (Some(fun () -> publish line))
            | None, None, None -> enqueueLine request.OnLine line.Text

        let publishGeneratedLine line =
            match request.OnGeneratedAdmission with
            | Some admit ->
                match request.OutputRedaction with
                | Some policy -> policy.Synchronize(fun () -> admit line)
                | None -> admit line
            | None -> enqueueLine (request.OnGeneratedLine |> Option.orElse request.OnLine) line

        // Interrupt narration is useful evidence, but its synchronous admission
        // may reject a run-wide exhausted budget or a broken publisher.  Never
        // let that prevent the group signal and reaping path below: retain the
        // first admission failure and surface it only after termination, extinction
        // verification, and reader settlement have been attempted.
        let mutable deferredGeneratedNarrationFailure: exn option = None

        let publishGeneratedLineBeforeCleanup line =
            try
                publishGeneratedLine line
            with error ->
                if deferredGeneratedNarrationFailure.IsNone then
                    deferredGeneratedNarrationFailure <- Some error

        let closeAndGetLineCallbackTail () =
            lock lineCallbackGate (fun () ->
                lineCallbacksOpen <- false
                lineCallbackTail)

        let emit (sink: Text.StringBuilder) (line: string) =
            if line <> null then
                if line.Length > OutputLimitCharacters then
                    reportOutputLimit ()
                elif not (hasOutputFailure ()) then
                    lock sink (fun () ->
                        if not (fitsOutputLine sink.Length line.Length Environment.NewLine.Length) then
                            reportOutputLimit ()
                        else
                            sink.AppendLine line |> ignore)

                    if not (hasOutputFailure ()) then publishLine line

        let emitRedacted
            admission
            (sink: Text.StringBuilder)
            (taggedSink: RedactedTextBuilder)
            consumedBufferedCharacters
            (line: RedactedText)
            =
            if line.Text.Length > OutputLimitCharacters then
                reportOutputLimit ()
                false
            elif not (hasOutputFailure ()) then
                lock sink (fun () ->
                    if not (fitsOutputLine sink.Length line.Text.Length Environment.NewLine.Length) then
                        reportOutputLimit ()
                    else
                        sink.AppendLine line.Text |> ignore
                        taggedSink.AppendLine line)

                if not (hasOutputFailure ()) then
                    publishRedactedLine admission consumedBufferedCharacters line
                    true
                else
                    false
            else
                false

        let handleStderrLine (line: string) =
            if line.StartsWith(pgidMarker, StringComparison.Ordinal) then
                // the leader's own pid: the real group id. Never surfaced to the
                // caller as build output.
                match
                    line.Substring(pgidMarker.Length).Split(
                        ' ',
                        StringSplitOptions.RemoveEmptyEntries)
                with
                | [| rawPid; rawAnchor |] ->
                    match Int32.TryParse rawPid, Int32.TryParse rawAnchor with
                    | (true, pid), (true, anchor) -> reportedPgid.TrySetResult(pid, anchor) |> ignore
                    | _ -> ()
                | _ -> ()
            else
                emit stderr line

        let stderrAdmission =
            match request.OutputRedaction with
            | Some _ -> request.CreateRedactedAdmission |> Option.map (fun create -> create ())
            | None -> None

        proc.Start() |> ignore

        // `Exited` is a process-handle notification. It does not wait for
        // redirected pipes to close, unlike Process.WaitForExit(): an escaped
        // descendant may inherit a write end and must not wedge step completion.
        if proc.HasExited then
            processExited.TrySetResult(()) |> ignore

        let captureBuffer = Text.StringBuilder()
        let mutable acceptingCapturedOutput = true

        let startRedactingReader
            (reader: IO.StreamReader)
            callbackGate
            (closed: Tasks.TaskCompletionSource<unit>)
            publish
            bufferedAdmission
            closeAdmission
            completePublication
            stripInitialControlFrame
            =
            let policy = request.OutputRedaction.Value
            let mutable acceptingRedactedOutput = 1
            // Assigned before the reader's first await. The outer freeze never
            // waits for callbackGate: a direct synchronous callback is allowed
            // to stall, but it must not admit a NEW chunk after return.
            let mutable closeLocalReaderState: unit -> unit = ignore

            let freezeRedactedReader () =
                // Close new reader work before acquiring the owner lease. A
                // reader already in policy.Synchronize then either finishes
                // before Close takes the output lock or sees this inner flag;
                // a fresh feed cannot slip between Close and the flag.
                Threading.Interlocked.Exchange(&acceptingRedactedOutput, 0) |> ignore

                try
                    closeAdmission |> Option.iter (fun close -> close ())
                finally
                    if Monitor.TryEnter(callbackGate) then
                        try
                            // Local matcher/framer state belongs only to this
                            // reader; do not take the policy lock here because a
                            // different synchronous callback may hold it.
                            closeLocalReaderState ()
                        finally
                            Monitor.Exit(callbackGate)

            let readerTask = task {
                let masker = policy.CreateMatcher()
                let releaseBuffered characters =
                    if characters > 0 then
                        bufferedAdmission |> Option.iter (fun buffered -> buffered.Release characters)

                let publishFramedLine consumed line =
                    if Threading.Volatile.Read(&acceptingRedactedOutput) = 0 || hasOutputFailure () then
                        releaseBuffered consumed
                    else
                        // Per-process buffering can reject a line before its
                        // run-wide admission. Those credits never transferred,
                        // so return them before the reader begins cleanup.
                        if not (publish (Some consumed) line) then
                            releaseBuffered consumed

                let framer = RedactedLineFramer(publishFramedLine, releaseBuffered, reportOutputLimit)
                let controlPrefix = Text.StringBuilder()
                let mutable controlResolved = not stripInitialControlFrame
                // Credits for matcher state which has not yet become framer
                // input. The matcher can retain a long almost-secret prefix
                // while returning an empty RedactedText; those bytes must be
                // part of the shared whole-build budget before EOF.
                let mutable matcherReservedCharacters = 0

                let reconcileMatcherOutput () (masked: RedactedText) =
                    let desired = masker.PendingCharacters + masked.Text.Length
                    let delta = desired - matcherReservedCharacters

                    if delta > 0 then
                        bufferedAdmission |> Option.iter (fun buffered -> buffered.Reserve delta)
                    elif delta < 0 then
                        releaseBuffered (-delta)

                    // Only the matcher's retained prefix remains local after
                    // the emitted portion is handed to the framer. Set this
                    // before Push so an admission exception cannot make the
                    // finally path release framer-owned credit twice.
                    matcherReservedCharacters <- masker.PendingCharacters

                let abandonMatcherReservation () =
                    if matcherReservedCharacters > 0 then
                        let abandoned = matcherReservedCharacters
                        matcherReservedCharacters <- 0
                        releaseBuffered abandoned

                let mutable localReaderStateClosed = false

                let closeLocalState () =
                    if not localReaderStateClosed then
                        localReaderStateClosed <- true
                        framer.Abandon()
                        abandonMatcherReservation ()
                        // Frozen readers never receive EOF authority. Drop the
                        // matcher's ambiguous raw suffix rather than completing
                        // it into output after the owning stream is closed.
                        masker.Abandon()
                        controlPrefix.Clear() |> ignore

                closeLocalReaderState <- closeLocalState

                let feedBuildOutput text =
                    if not (String.IsNullOrEmpty text) then
                        // Charge decoded process input *before* the matcher.
                        // A matcher may retain all of an almost-secret prefix
                        // and return no text for the framer until a later
                        // chunk or EOF.
                        bufferedAdmission |> Option.iter (fun buffered -> buffered.Reserve text.Length)
                        matcherReservedCharacters <- matcherReservedCharacters + text.Length
                        let masked = masker.PushRedacted text
                        reconcileMatcherOutput () masked

                        if not (String.IsNullOrEmpty masked.Text) then
                            framer.Push masked

                let feed text =
                    if controlResolved then
                        feedBuildOutput text
                    else
                        controlPrefix.Append text |> ignore
                        let buffered = controlPrefix.ToString()
                        let newline = buffered.IndexOf '\n'

                        if newline >= 0 then
                            let controlLine = buffered.Substring(0, newline).TrimEnd '\r'
                            controlResolved <- true

                            if controlLine.StartsWith(pgidMarker, StringComparison.Ordinal) then
                                // Parse the private bootstrap frame before any
                                // credential form can alter its pid fields.
                                handleStderrLine controlLine
                                feedBuildOutput (buffered.Substring(newline + 1))
                            else
                                feedBuildOutput buffered

                            controlPrefix.Clear() |> ignore
                        elif buffered.Length > pgidMarker.Length + 64 then
                            // The bootstrap frame is fixed and short. If it is
                            // malformed, stop granting it unbounded private state
                            // and treat the bytes as ordinary build output.
                            controlResolved <- true
                            feedBuildOutput buffered
                            controlPrefix.Clear() |> ignore

                try
                    let chunk = Array.zeroCreate<char> 4096
                    let mutable reading = true

                    while reading do
                        let! n = reader.ReadAsync(chunk, 0, chunk.Length)

                        if n > 0 then
                            lock callbackGate (fun () ->
                                if Threading.Volatile.Read(&acceptingRedactedOutput) = 0 then
                                    closeLocalState ()
                                elif not (hasOutputFailure ()) then
                                    try
                                        policy.Synchronize(fun () ->
                                            // A freeze can race a reader which
                                            // already acquired callbackGate.
                                            // Recheck inside Synchronize before
                                            // raw reservation or matcher state.
                                            if Threading.Volatile.Read(&acceptingRedactedOutput) = 0 then
                                                closeLocalState ()
                                            else
                                                feed (String(chunk, 0, n)) )
                                    with error ->
                                        // A shared quota rejection must wake an
                                        // otherwise unbounded run. Keep draining
                                        // the pipe while the main path terminates
                                        // and verifies the process group.
                                        reportOutputFailure error)
                        else
                            reading <- false

                    lock callbackGate (fun () ->
                        try
                            policy.Synchronize(fun () ->
                                if Threading.Volatile.Read(&acceptingRedactedOutput) = 0 then
                                    closeLocalState ()
                                else
                                    if not (hasOutputFailure ()) then
                                        if not controlResolved && controlPrefix.Length > 0 then
                                            feedBuildOutput (controlPrefix.ToString())
                                            controlPrefix.Clear() |> ignore

                                        let suffix = masker.CompleteRedacted()
                                        reconcileMatcherOutput () suffix

                                        if not (String.IsNullOrEmpty suffix.Text) then
                                            framer.Push suffix

                                        framer.Complete()
                                    else
                                        closeLocalState ()

                                    // A direct synchronous Admit can have
                                    // stalled inside framer.Complete. Recheck
                                    // after it returns: bounded finalization
                                    // may have frozen this reader meanwhile.
                                    if Threading.Volatile.Read(&acceptingRedactedOutput) = 0 then
                                        closeLocalState ()
                                    else
                                        completePublication |> Option.iter (fun complete -> complete ()))
                        with error ->
                            closeLocalState ()
                            reportOutputFailure error)
                finally
                    lock callbackGate (fun () -> closeLocalState ())

                    closed.TrySetResult(()) |> ignore
            }
            (readerTask :> Tasks.Task), freezeRedactedReader

        let startRawReader
            (reader: IO.StreamReader)
            callbackGate
            (closed: Tasks.TaskCompletionSource<unit>)
            publish
            =
            task {
                let framer = RawLineFramer((fun _ line -> publish line), ignore, reportOutputLimit)

                try
                    let chunk = Array.zeroCreate<char> 4096
                    let mutable reading = true

                    while reading do
                        let! n = reader.ReadAsync(chunk, 0, chunk.Length)

                        if n > 0 then
                            lock callbackGate (fun () ->
                                if not (hasOutputFailure ()) then
                                    framer.Push(String(chunk, 0, n)))
                        else
                            reading <- false

                    lock callbackGate (fun () ->
                        if not (hasOutputFailure ()) then framer.Complete())
                finally
                    closed.TrySetResult(()) |> ignore
            }
            :> Tasks.Task

        let redactingStdoutReader =
            match request.OutputRedaction, request.SuppressStdoutEcho with
            | Some _, false ->
                let stdoutAdmission = request.CreateRedactedAdmission |> Option.map (fun create -> create ())
                Some(
                    startRedactingReader
                        proc.StandardOutput
                        stdoutCallbackGate
                        stdoutClosed
                        (emitRedacted stdoutAdmission stdout stdoutRedacted)
                        (stdoutAdmission |> Option.bind (fun admission -> admission.Buffered))
                        (stdoutAdmission |> Option.bind (fun admission -> admission.Close))
                        (stdoutAdmission |> Option.map _.Complete)
                        false)
            | _ -> None

        let redactingStderrReader =
            match request.OutputRedaction with
            | Some _ ->
                Some(
                    startRedactingReader
                        proc.StandardError
                        stderrCallbackGate
                        stderrClosed
                        (fun consumed line ->
                            if line.Text.StartsWith(pgidMarker, StringComparison.Ordinal) then
                                handleStderrLine line.Text
                                false
                            else
                                emitRedacted stderrAdmission stderr stderrRedacted consumed line)
                        (stderrAdmission |> Option.bind (fun admission -> admission.Buffered))
                        (stderrAdmission |> Option.bind (fun admission -> admission.Close))
                        (stderrAdmission |> Option.map _.Complete)
                        true)
            | None -> None

        let capturedStdout =
            if request.SuppressStdoutEcho then
                let reader = proc.StandardOutput
                // A char buffer, not a byte one: `StreamReader.Read` decodes, so a chunk
                // boundary can never split a multi-byte character. Reading bytes here to
                // make the comment above literally true would introduce that bug.
                Some(
                    task {
                        let chunk = Array.zeroCreate<char> 4096
                        let mutable reading = true

                        while reading do
                            let! n = reader.ReadAsync(chunk, 0, chunk.Length)

                            if n > 0 then
                                lock captureBuffer (fun () ->
                                    // Capture return is a synchronization
                                    // boundary. An escaped descendant may keep
                                    // this pipe open after the bounded EOF wait;
                                    // continue draining it, but never let that
                                    // late data reserve run-wide budget or alter
                                    // a completed step after its snapshot.
                                    if not acceptingCapturedOutput then
                                        ()
                                    elif n > OutputLimitCharacters - captureBuffer.Length then
                                        reportOutputLimit ()
                                    elif not (hasOutputFailure ()) then
                                        try
                                            request.ReserveCapturedOutput |> Option.iter (fun reserve -> reserve n)
                                            captureBuffer.Append(chunk, 0, n) |> ignore
                                        with error ->
                                            // Wake even an otherwise unbounded wait;
                                            // continue draining while cleanup reaps
                                            // the group, then propagate the cause.
                                            reportOutputFailure error)
                            else
                                reading <- false
                    }
                    :> Tasks.Task)
            else
                None

        let rawStdoutReader =
            match request.SuppressStdoutEcho, redactingStdoutReader with
            | false, None -> Some(startRawReader proc.StandardOutput stdoutCallbackGate stdoutClosed (emit stdout))
            | _ -> None

        let rawStderrReader =
            match redactingStderrReader with
            | None -> Some(startRawReader proc.StandardError stderrCallbackGate stderrClosed handleStderrLine)
            | _ -> None

        let stdoutReaderCompleted: Tasks.Task =
            match capturedStdout with
            | Some task -> task
            | None ->
                redactingStdoutReader
                |> Option.map fst
                |> Option.orElse rawStdoutReader
                |> Option.defaultValue (stdoutClosed.Task :> Tasks.Task)

        let stderrReaderCompleted: Tasks.Task =
            redactingStderrReader
            |> Option.map fst
            |> Option.orElse rawStderrReader
            |> Option.defaultValue (stderrClosed.Task :> Tasks.Task)

        let allReadersCompleted =
            Tasks.Task.WhenAll [| stdoutReaderCompleted; stderrReaderCompleted |]

        // Capture mode intentionally permits an escaped holder of the raw stdout
        // pipe and retains the bytes already read. Stderr still publishes through
        // its incremental reader and OnLine, so its EOF is load-bearing before the callback-tail
        // snapshot: otherwise an escaped stderr writer could enqueue after return.
        let callbackReadersCompleted: Tasks.Task =
            if request.SuppressStdoutEcho then
                stderrReaderCompleted
            else
                allReadersCompleted

        let mutable registeredGroup: RegisteredGroupIdentity option = None

        // Wait for the leader marker or definitive stderr EOF, with the same
        // two-second upper bound as before. Deriving it from proc.Id is WRONG:
        // that is setsid's pid, in our own group. EOF is load-bearing for a
        // very short command: it proves no late marker callback remains, instead
        // of paying a flat 50ms and hoping the callback catches up.
        let pgid =
            Tasks.Task.WhenAny(
                [| reportedPgid.Task :> Tasks.Task
                   stderrClosed.Task :> Tasks.Task
                   Tasks.Task.Delay 2_000 |])
                .GetAwaiter()
                .GetResult()
            |> ignore

            if reportedPgid.Task.IsCompletedSuccessfully then
                let group, anchor = reportedPgid.Task.Result

                try
                    let startTime =
                        match processStateAndStartTime group with
                        | ProcessIdentityState.Matching _, Some value -> value
                        | _ -> invalidOp $"could not bind process group {group} to its Linux start time"

                    let anchorStartTime =
                        match containmentDirectory with
                        | None when anchor = 0 -> "-"
                        | Some _ when anchor > 1 && Native.processGroupOf anchor = Some group ->
                            match processStateAndStartTime anchor with
                            | ProcessIdentityState.Matching _, Some value -> value
                            | _ -> invalidOp $"could not bind process-group anchor {anchor} to its Linux start time"
                        | _ -> invalidOp $"process group {group} did not report a valid containment anchor"

                    persistGroup group startTime anchor anchorStartTime

                    match containmentDirectory with
                    | Some _ ->
                        let anchorStopped =
                            waitForIdentityStop
                                200
                                (fun () -> observeIdentity anchor anchorStartTime)
                                (fun () -> Thread.Sleep 10)

                        if not anchorStopped then
                            invalidOp $"process-group anchor {anchor} did not reach its identity-bound stopped state"

                        registeredGroup <-
                            Some
                                { GroupId = group
                                  LeaderStartTime = startTime
                                  AnchorPid = anchor
                                  AnchorStartTime = anchorStartTime }
                    | None -> ()

                    let stopped =
                        waitForIdentityStop
                            200
                            (fun () -> observeIdentity group startTime)
                            (fun () -> Thread.Sleep 10)

                    if not stopped then
                        invalidOp $"process group {group} did not reach an identity-bound stopped state"

                    // Release only the identity-checked leader. The stopped
                    // anchor must remain stopped so a later group TERM stays
                    // pending on it throughout the user's grace window.
                    if not (Native.signalProcess group Native.SIGCONT) then
                        invalidOp $"could not release registered process group {group}"

                    Some group
                with _ ->
                    // Closing the sole writer wakes the out-of-group watchdog;
                    // the stopped child cannot execute user code before cleanup.
                    proc.StandardInput.Close()
                    reraise ()
            else
                // A missing marker cannot leave a stopped, unregistered child.
                // EOF delegates cleanup to the wrapper's watchdog.
                proc.StandardInput.Close()
                None

        // NOTE: never use the parameterless WaitForExit() with redirected
        // output. It waits for the *pipes* to close, and a backgrounded
        // grandchild inherits them — so a step that spawns a daemon would hang
        // the executor forever. Wait on the process handle only, then give the
        // async readers a bounded window to flush.
        let interrupted () =
            match request.Interrupt with
            | Some p -> (try p () with _ -> false)
            | None -> false

        // The CAUSE is decided once, at the moment the wait ends — re-sampling
        // `interrupted()` afterwards raced a sibling failing just after a deadline
        // expiry, flipping both the narration and the reported outcome.
        let waitForProcessExit (budgetMs: int64 option) =
            let expired () =
                // measured against `sw`, which started at the TOP of this run —
                // a clock created here would exclude script creation, launch, and
                // the up-to-two-second pgid wait, quietly extending every budget
                match budgetMs with
                | Some ms -> sw.ElapsedMilliseconds >= ms
                | None -> false

            let nextWaitMilliseconds () =
                let remaining =
                    budgetMs
                    |> Option.map (fun ms -> max 0L (ms - sw.ElapsedMilliseconds))

                // The interrupt contract is a predicate, not a wait handle, so
                // only interruptible steps still need a bounded re-sample. An
                // ordinary step sleeps until exit, output-limit notification or
                // its exact remaining deadline; there is no 10ms exit poll.
                match request.Interrupt, remaining with
                | Some _, Some ms -> int (min 10L ms)
                | Some _, None -> 10
                | None, Some ms -> int (min (int64 Int32.MaxValue) ms)
                | None, None -> Timeout.Infinite

            let mutable cause =
                if processExited.Task.IsCompleted || proc.HasExited then
                    WaitEnd.Exited
                else
                    WaitEnd.Waiting

            while cause = WaitEnd.Waiting do
                if processExited.Task.IsCompleted || proc.HasExited then
                    cause <- WaitEnd.Exited
                elif hasOutputFailure () then
                    // Keep draining readers while the same identity-safe group
                    // cleanup runs below; do not wait for a hostile producer to
                    // finish writing after its output was rejected.
                    cause <- WaitEnd.OutputLimit
                else
                    match expired (), interrupted () with
                    | false, false ->
                        let delay = Tasks.Task.Delay(nextWaitMilliseconds ())

                        let completed =
                            Tasks.Task.WhenAny(
                                [| processExited.Task :> Tasks.Task
                                   outputLimitReached.Task :> Tasks.Task
                                   delay |])
                                .GetAwaiter()
                                .GetResult()

                        if Object.ReferenceEquals(completed, processExited.Task) then
                            cause <- WaitEnd.Exited
                    | false, true ->
                        // the LOCAL budget clock starts after launch overhead, so it
                        // can lag the walker's absolute deadline — an interrupt seen
                        // first here may still be the LATER event. The caller's
                        // ordering is authoritative in both directions.
                        let interruptFirst =
                            match request.InterruptBeatsDeadline with
                            | Some beats -> (try beats () with _ -> true)
                            | None -> true

                        cause <-
                            if interruptFirst || request.TimeoutMs.IsNone then
                                WaitEnd.Interrupted
                            else
                                WaitEnd.Expired
                    | true, _ ->
                        // EVERY observed expiry consults the caller's timestamps, not
                        // only a both-at-once tie: the sibling STAMP is written before
                        // its cancel signal fires, so the interrupt predicate can lag
                        // an event that was genuinely earlier.
                        let interruptFirst =
                            match request.InterruptBeatsDeadline with
                            | Some beats -> (try beats () with _ -> false)
                            | None -> false

                        cause <- if interruptFirst then WaitEnd.Interrupted else WaitEnd.Expired

            cause

        let waitForTaskWithin (clock: Stopwatch) (budgetMs: int) (task: Tasks.Task) =
            let remaining = max 0 (budgetMs - int clock.ElapsedMilliseconds)

            if task.IsCompleted then
                true
            elif remaining <= 0 then
                false
            else
                let completed =
                    Tasks.Task.WhenAny(
                        [| task
                           Tasks.Task.Delay remaining |])
                        .GetAwaiter()
                        .GetResult()

                obj.ReferenceEquals(completed, task)

        let waitForReaderCompletion (budgetMs: int) =
            // EOF/task completion, not an unchanged-length guess. A descendant
            // can hold a pipe open indefinitely, so completion is still bounded;
            // expiry keeps every byte already appended and never blocks the run.
            let clock = Stopwatch.StartNew()
            let allReachedEof = waitForTaskWithin clock budgetMs allReadersCompleted
            clock, allReachedEof, callbackReadersCompleted.IsCompletedSuccessfully

        let waitForLineCallbackCompletion budgetMs clock callbackReadersReachedEof : exn option * exn option =
            // Close callback admission under the same lock as enqueue before
            // snapshotting the tail, so an escaped writer cannot append later.
            let tail = closeAndGetLineCallbackTail ()

            let processOutputCallbackPresent =
                Option.isSome request.OnLine
                || (Option.isSome request.OutputRedaction
                    && (Option.isSome request.OnRedactedLine
                        || Option.isSome request.OnRedactedAdmission
                        || Option.isSome request.CreateRedactedAdmission))

            if processOutputCallbackPresent && not callbackReadersReachedEof then
                None,
                Some(
                    TimeoutException(
                        $"progressive output reader did not reach EOF within the shared {budgetMs}ms output-drain budget"))
            elif waitForTaskWithin clock budgetMs tail then
                try
                    tail.GetAwaiter().GetResult()
                    None, None
                with error ->
                    Some error, None
            else
                None,
                Some(
                    TimeoutException(
                        $"OnLine callback tail did not complete within the shared {budgetMs}ms output-drain budget"))

        let settleBeforeSignal (budgetMs: int) =
            // RESIDUAL, deliberately not described as event-driven. Process does
            // not expose the instant at which bytes become queued to the reader
            // callbacks, so pre/post-signal causality still needs the old bounded
            // quiet sample. This runs only on abort paths; ordinary completion no
            // longer pays it. The snapshots below remain the classification boundary.
            let clock = Stopwatch.StartNew()

            let drainActiveCallback gate =
                let remaining = max 0 (budgetMs - int clock.ElapsedMilliseconds)

                if Monitor.TryEnter(gate, remaining) then
                    Monitor.Exit gate

            // A reader callback already appending is knowable and should not be
            // left behind the snapshot. User callbacks execute on their separate
            // serialized tail, so they cannot stall ingestion. The quiet sample
            // still covers reader callbacks Process has queued but not invoked yet.
            drainActiveCallback stdoutCallbackGate
            drainActiveCallback stderrCallbackGate

            settleOutputUntilQuiet
                budgetMs
                (fun () -> clock.ElapsedMilliseconds)
                Thread.Sleep
                (fun () ->
                    lock stdout (fun () -> stdout.Length), lock stderr (fun () -> stderr.Length))

        let waitEnd = waitForProcessExit request.TimeoutMs
        let finished = waitEnd = WaitEnd.Exited

        let outcome, termination, outputCompletionClock, outputCompletionBudget, callbackReadersReachedEof =
            if finished then
                let code = proc.ExitCode

                let t =
                    if request.ReapGroup then
                        pgid
                        |> Option.map (fun g ->
                            match registeredGroup with
                            | Some identity -> reapWithAnchor identity request.GraceMs
                            | None -> reap g request.GraceMs)
                    else
                        None
                // A production containment anchor intentionally outlives the
                // direct leader. Reap the group before requiring reader EOF;
                // otherwise that controller-owned survivor makes every normal
                // Run.Host shell look like an escaped callback writer. Readers
                // stay active during reaping, then share the existing 500ms bound.
                let completionClock, _, callbackReadersReachedEof = waitForReaderCompletion 500


                // On Linux a process killed by signal N exits 128+N.
                //
                // REVIEW FIXES (Codex P2 + Copilot, PR #11), both correct:
                //  * the range stopped at 164, covering signals 1..36, but Linux
                //    has signals up to 64 (exit 192), so a high-numbered signal was
                //    silently reported as an ordinary exit code;
                //  * this is a HEURISTIC and cannot be otherwise here. `setsid
                //    --wait` propagates "the same return", so the wait-status bit
                //    that distinguishes "killed by signal 9" from "exited 137" is
                //    already gone by the time .NET reports ExitCode. A script that
                //    deliberately calls `exit 137` is indistinguishable from one
                //    that was SIGKILLed. The diagnostic must therefore say "likely",
                //    and FG-033's claim is corrected accordingly — see the board.
                let outcome =
                    if code > 128 && code <= 192 then Signalled(code - 128) else Completed code

                outcome, t, completionClock, 500, callbackReadersReachedEof
            elif waitEnd = WaitEnd.OutputLimit then
                let t =
                    pgid
                    |> Option.map (fun g ->
                        match registeredGroup with
                        | Some identity -> terminateGroupWithAnchor identity request.GraceMs
                        | None -> terminateGroup g request.GraceMs)

                let completionClock, _, callbackReadersReachedEof = waitForReaderCompletion 300
                Completed 125, t, completionClock, 300, callbackReadersReachedEof
            else
                if waitEnd = WaitEnd.Expired then
                    publishGeneratedLineBeforeCleanup "Cancelling nested steps due to timeout"

                publishGeneratedLineBeforeCleanup "Sending interrupt signal to process"

                settleBeforeSignal 300
                let outputBeforeSignal = lock stdout (fun () -> stdout.ToString())
                let stderrBeforeSignal = lock stderr (fun () -> stderr.ToString())
                let t =
                    pgid
                    |> Option.map (fun g ->
                        match registeredGroup with
                        | Some identity -> terminateGroupWithAnchor identity request.GraceMs
                        | None -> terminateGroup g request.GraceMs)
                let completionClock, _, callbackReadersReachedEof = waitForReaderCompletion 300

                let shellSaidIt =
                    let since (sink: Text.StringBuilder) (before: string) =
                        (lock sink (fun () -> sink.ToString())).Substring before.Length

                    [ since stdout outputBeforeSignal; since stderr stderrBeforeSignal ]
                    |> List.exists (fun afterSignal ->
                        afterSignal.Replace("\r\n", "\n").Split '\n'
                        |> Array.exists (fun line -> line.Trim() = "Terminated"))

                if not shellSaidIt then
                    publishGeneratedLineBeforeCleanup "Terminated"
                // Distinguish the two ways a step can fail to finish. Both take
                // the same signal path; only the reported cause differs.
                (if waitEnd = WaitEnd.Interrupted then Cancelled else TimedOut), t, completionClock, 300, callbackReadersReachedEof

        // Defer propagation until after process-group guard and secret-bearing
        // script cleanup. The run still fails closed, but never trades an output
        // publication failure for a leaked containment guard or durable script.
        let lineCallbackFailure, lineCallbackSettlementTimeout =
            waitForLineCallbackCompletion
                outputCompletionBudget
                outputCompletionClock
                callbackReadersReachedEof

        // A bounded reader wait is also an ownership boundary. Close Walker's
        // per-stream admission lease before constructing the result so an
        // escaped pipe holder cannot mutate a later step's shared budget. Do
        // not let an unexpected direct Close implementation skip remaining
        // readers or cleanup; retain it for final propagation instead.
        let mutable deferredReaderCloseFailure: exn option = None

        let freezeRedactingReader reader =
            try
                reader |> Option.iter (fun (_, freeze) -> freeze ())
            with error ->
                if deferredReaderCloseFailure.IsNone then
                    deferredReaderCloseFailure <- Some error

        freezeRedactingReader redactingStdoutReader
        freezeRedactingReader redactingStderrReader

        let readerFailure =
            if allReadersCompleted.IsFaulted then
                try
                    allReadersCompleted.GetAwaiter().GetResult()
                    None
                with error ->
                    Some error
            else
                None

        // The guard outlives the inner leader. This closes the interval between
        // leader exit and group reaping: if Run.Host dies there, stdin reaches
        // EOF and the guard kills surviving descendants. Disarm only after
        // extinction is verified. Outside controller containment, ReapGroup=false
        // retains its historical opt-out by explicitly disarming the guard.
        let mayDisarmGuard =
            match containmentDirectory, pgid with
            | None, _ -> true
            | Some _, Some group ->
                Native.probeProcessGroup group = Native.ProcessGroupPresence.Absent
            | Some _, None -> false

        let mutable guardDisarmed = false

        try
            if mayDisarmGuard then
                proc.StandardInput.WriteLine "disarm"
                proc.StandardInput.Flush()
                guardDisarmed <- true

            proc.StandardInput.Close()
        with _ ->
            ()

        // Keep the anchor-bound record available until the disarm command is in
        // the pipe. If Run.Host dies before that point, the guard still has the
        // provenance it needs; after the flush it will read `disarm`, not EOF.
        if guardDisarmed then
            pgid |> Option.iter forgetExtinguishedGroup

        sw.Stop()

        shebangFile |> Option.iter deleteShebang

        // Reader completion has already received its single bounded wait above. Never
        // wait on the capture task again here: an escaped descendant can retain the pipe,
        // and a second five-second wait made that earlier bound fictional. Snapshot the
        // incrementally-owned buffer; completed reads are exact and incomplete reads
        // retain every character which arrived before the bound.
        //
        // "BEST-EFFORT" NOW MEANS WHAT IT SAYS, and it took two goes. The bound was always
        // right; what was salvaged when it expired was not. First the fallback read
        // `stdout.ToString()`, which in capture mode is ALWAYS "" — the line handler is
        // not attached at all, so that sink is never filled — while the comment called the
        // value best-effort, implying partial output survived. It did not. Making the
        // fallback an explicit "" was honest about that and still WRONG (FG-181): bytes
        // that arrived before the bound are real captured output, and discarding them
        // hands the pipeline a wrong value under a build that reports success. The buffer
        // above keeps them, so an expired wait TRUNCATES what was captured rather than
        // ERASING it, and the timeout is no longer the difference between `token` and "".
        //
        // WHY NOT SIMPLY WAIT LONGER: the bound is what stops an escaped descendant from
        // holding the engine open forever, which is the one failure mode worse than a
        // wrong value. Truncation removes the need to choose between them.
        // Capture completion is sampled BEFORE the buffer. If EOF races this
        // snapshot, false is conservative and the public copy withholds an
        // ambiguous suffix; true proves every append preceded the snapshot.
        let stdoutReachedEof = stdoutReaderCompleted.IsCompletedSuccessfully

        let capturedText =
            capturedStdout
            |> Option.map (fun _ ->
                lock captureBuffer (fun () ->
                    acceptingCapturedOutput <- false
                    captureBuffer.ToString()))

        let bufferedStdout = lock stdout (fun () -> stdout.ToString())
        let bufferedStderr = lock stderr (fun () -> stderr.ToString())
        let bufferedStdoutRedacted =
            match request.OutputRedaction, request.SuppressStdoutEcho with
            | Some _, false -> Some(lock stdout (fun () -> stdoutRedacted.ToRedactedText()))
            | _ -> None

        let bufferedStderrRedacted =
            request.OutputRedaction
            |> Option.map (fun _ -> lock stderr (fun () -> stderrRedacted.ToRedactedText()))

        let result =
            { Outcome = outcome
              Stdout = defaultArg capturedText bufferedStdout
              StdoutRedacted = bufferedStdoutRedacted
              StdoutReachedEof = stdoutReachedEof
              Stderr = bufferedStderr
              StderrRedacted = bufferedStderrRedacted
              DurationMs = sw.ElapsedMilliseconds
              ProcessGroupId = pgid
              Termination = termination
              CleanupFailure = cleanupFailure
              DurableId = mintedDurableId }

        // A failed publication sink is an existing sticky infrastructure cause
        // with stronger reconciliation requirements than the output limit. A
        // bounded settlement timeout only says its queued callbacks could not
        // finish in time; when an output overflow already explains the run, it
        // must not replace that explicit cause.
        let finalFailure =
            readerFailure
            |> Option.orElse lineCallbackFailure
            // An in-flight process callback can establish lost host output
            // independently of a later rejected interrupt narration. Keep
            // that transport uncertainty first, but never let a bare reader
            // settlement timeout erase the retained narration failure.
            |> Option.orElse deferredGeneratedNarrationFailure
            |> Option.orElse deferredReaderCloseFailure
            |> Option.orElse outputFailure
            |> Option.orElse lineCallbackSettlementTimeout

        match finalFailure with
        | None -> result
        | Some error ->
            Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(error).Throw()
            Unchecked.defaultof<RunResult>
