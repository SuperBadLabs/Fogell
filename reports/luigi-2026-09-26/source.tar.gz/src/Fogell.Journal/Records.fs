namespace Fogell.Journal

open Fogell.Domain

type Record =
    /// A step is ABOUT to run. Written and made durable BEFORE execution, so a
    /// crash between the write and the effect is recoverable — we know the step
    /// may have started, which is the only honest state.
    | StepStarted of stage: string * stepIndex: int * stepName: string
    /// A step finished with a known outcome. Only this record makes a step safe
    /// to skip on resume.
    | StepFinished of stage: string * stepIndex: int * status: BuildStatus
    | StepStageWarning of stage: string * stepIndex: int * status: BuildStatus
    /// A stage boundary — the point at which the journal is fsynced (group
    /// commit). Everything before it is durable.
    | StageCommitted of stage: string
    | BuildFinished of status: BuildStatus
    /// FG-112. The sha256 of the pipeline definition this journal belongs to.
    /// A resume against a CHANGED definition would hybrid-execute two
    /// pipelines against one key space — the digest lets it refuse by name.
    | ScriptDigest of sha256: string
    /// FG-046b. This build's own identity, minted once by its first attempt and
    /// read by every later one. Approval action ids derive from it.
    ///
    /// It exists because deriving that identity from the journal's PATH cannot
    /// be made correct: `resolve` canonicalises symlinks, but a hard link is a
    /// second name for the same inode with no distinguished original, so two
    /// spellings of one journal produced two different ids — and an answer
    /// written under the first was invisible to an attempt opened through the
    /// second, which then asked the human again. A name the journal CARRIES has
    /// no aliases.
    | BuildIdentity of id: string
    /// FG-112. The workspace this journal's build ran in — ROOT and JOB
    /// separately, because distinct pairs can combine to one path while their
    /// controller-side state (artifacts, stashes, SCM records — all under the
    /// root) differs. A resume pointed elsewhere refuses by name.
    | WorkspaceIdentity of root: string * job: string
    | InputDecision of
        stage: string *
        stepIndex: int *
        occurrence: int *
        approved: bool *
        submitter: string
    /// FG-046b. An answer that arrived but was REFUSED — it was first observed
    /// after the prompt's deadline had already passed, or after a failFast
    /// sibling had already failed. The decision record stays (a human really did
    /// answer, and the audit trail should say so); this says it was not acted on
    /// and must never be.
    ///
    /// Durable because the alternative replays it. A refused-as-late answer that
    /// is durable but unmarked survives a kill in the window before the abort is
    /// recorded, and the resumed attempt — with a FRESH deadline — finds it on
    /// record, honours it, and walks past the gate the timeout had already
    /// closed. The safety bound is then defeated by a crash rather than by an
    /// approval.
    | InputDecisionVoided of stage: string * stepIndex: int * occurrence: int
    /// FG-046b. An answer that has been READ but not yet ruled eligible. It says
    /// a human answered — it is not lost, and an operator can see it — but it is
    /// NOT actionable, so resume will not act on it.
    ///
    /// It exists because eligibility cannot be decided before the write. A
    /// deadline-bound prompt must refuse an answer first observed after expiry,
    /// and the read itself takes time: the inbox read, the append and the FSYNC
    /// can all straddle the deadline. Recording the answer as actionable and
    /// voiding it afterwards leaves a window — crash between the two and the
    /// resumed attempt finds a usable approval for a gate that had already
    /// closed. So a bounded prompt records the answer provisionally and the
    /// walker rules on it against the deadline IN THE ATTEMPT THAT READ IT.
    ///
    /// IT IS NEVER PROMOTED. This said "and only then is it promoted to an
    /// actionable [InputDecision]", describing a design that was replaced — the
    /// host appends EITHER this record (cancellable prompt) OR an
    /// [InputDecision] (unbounded), never one and then the other, and nothing
    /// rewrites a provisional answer into a decision. A reader trusting the old
    /// sentence would expect a bounded answer to survive a restart, which is the
    /// precise opposite of the FG-046b safety model: it stays provisional, so a
    /// resumed attempt asks again rather than acting on an answer whose
    /// eligibility it cannot re-derive.
    ///
    /// An UNBOUNDED prompt skips all of this: with no deadline an answer cannot
    /// be late, so it is actionable when written.
    /// FG-046b. This prompt could be CANCELLED while it waited — it had a
    /// deadline, or a failFast sibling that could interrupt it. Written the
    /// first time such a prompt polls, because the journal otherwise cannot tell
    /// a gate that could expire from one that could only ever be answered.
    ///
    /// An answer to a cancellable prompt is actionable ONLY inside the attempt
    /// that read it, and this record is what enforces that afterwards. The
    /// reason is not a missing check, it is arithmetic: eligibility depends on
    /// TIME, making an answer actionable is a durable write, and time passes
    /// during the write. Check-then-write and write-then-check both leave a
    /// window, and so does voiding afterwards — that chase produced four
    /// findings before the shape became clear. So a cancellable prompt's answer
    /// is never promoted at all: it stays [InputAnswerProvisional] for the audit
    /// trail, no later attempt may act on it, and adoption refuses it. Closing
    /// that honestly needs an ABSOLUTE deadline on record so a resumed attempt
    /// can re-judge eligibility itself — FG-046c, which starts with a
    /// measurement.
    | InputPromptCancellable of stage: string * stepIndex: int * occurrence: int
    /// FG-114. WHY a step finished the way it did — the ERROR-shaped diagnostic
    /// the walker emitted, made durable beside the status it explains. Written
    /// only for failed or aborted steps, and only when one of the CAPTURE SITES
    /// held the text: step-result classification, the script-arm fail helper,
    /// and the two input option refusals. A refusal raised elsewhere (a
    /// credential binding, a git step, a `when` condition) still journals its
    /// disposition with no reason — tighten a lane on one of those and the
    /// assertion fails until its site captures too. A durable build record
    /// whose whole explanation is the word `failure` sent every reader to a
    /// console that no longer says why, and four approval-lane scenarios could
    /// prove a refusal happened without being able to prove WHICH rule refused.
    | StepReason of stage: string * stepIndex: int * reason: string
    /// FG-135. Retry attempt N of a JOURNALED retried stage is starting. The
    /// records BEFORE this marker for that stage belong to superseded attempts:
    /// a failed attempt's `step-finished failure` must not read as durably
    /// finished to the resume, or the resumed build skips the very step the
    /// next attempt exists to re-run. Attempt 1 writes no marker — its absence
    /// IS attempt 1, which keeps every pre-FG-135 journal readable unchanged.
    | RetryAttemptStarted of stage: string * attempt: int
    | InputAnswerProvisional of
        stage: string *
        stepIndex: int *
        occurrence: int *
        approved: bool *
        submitter: string

module Record =

    /// FG-046b. A field that came from OUTSIDE the engine (an approval's
    /// submitter is whatever the approver wrote) cannot be allowed to carry a
    /// tab or a newline into a tab-separated, line-per-record journal: the
    /// resulting line would decode to None, `Journal.read` stops at the first
    /// undecodable line, and every durable record BEHIND it would be forgotten
    /// — steps re-running is exactly the at-least-once outcome ADR 0003 exists
    /// to reject. Separators become spaces; nothing else is touched.
    let private oneLine (s: string) =
        if isNull s then
            ""
        else
            s.Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ')

    /// Text encoding, one record per line, tab separated. Deliberately plain: a
    /// journal that cannot be read with `cat` during an incident is worse than a
    /// slightly larger one.
    let encode =
        function
        | StepStarted(stage, i, name) -> $"step-started\t{stage}\t{i}\t{name}"
        | StepFinished(stage, i, status) -> $"step-finished\t{stage}\t{i}\t{BuildStatus.toWireString status}"
        | StepStageWarning(stage, i, status) ->
            $"step-stage-warning\t{stage}\t{i}\t{BuildStatus.toWireString status}"
        | StageCommitted stage -> $"stage-committed\t{stage}"
        | BuildFinished status -> $"build-finished\t{BuildStatus.toWireString status}"
        | ScriptDigest d -> $"script-digest\t{d}"
        | WorkspaceIdentity(r, j) -> $"workspace-identity\t{r}\t{j}"
        | BuildIdentity id -> $"build-identity\t{oneLine id}"
        | InputDecision(stage, i, occurrence, approved, who) ->
            let verdict = if approved then "approved" else "rejected"
            $"input-decision\t{oneLine stage}\t{i}\t{occurrence}\t{verdict}\t{oneLine who}"
        | InputDecisionVoided(stage, i, occurrence) -> $"input-decision-voided\t{oneLine stage}\t{i}\t{occurrence}"
        | InputPromptCancellable(stage, i, occurrence) -> $"input-prompt-cancellable\t{oneLine stage}\t{i}\t{occurrence}"
        | RetryAttemptStarted(stage, attempt) -> $"retry-attempt\t{oneLine stage}\t{attempt}"
        | StepReason(stage, i, reason) -> $"step-reason\t{oneLine stage}\t{i}\t{oneLine reason}"
        | InputAnswerProvisional(stage, i, occurrence, approved, who) ->
            let verdict = if approved then "approved" else "rejected"
            $"input-answer-provisional\t{oneLine stage}\t{i}\t{occurrence}\t{verdict}\t{oneLine who}"

    let decode (line: string) : Record option =
        match line.Split '\t' with
        | [| "step-started"; stage; i; name |] ->
            match System.Int32.TryParse i with
            | true, idx -> Some(StepStarted(stage, idx, name))
            | _ -> None
        | [| "step-finished"; stage; i; status |] ->
            match System.Int32.TryParse i, BuildStatus.ofWireString status with
            | (true, idx), Some s -> Some(StepFinished(stage, idx, s))
            | _ -> None
        | [| "step-stage-warning"; stage; i; status |] ->
            match System.Int32.TryParse i, BuildStatus.ofWireString status with
            | (true, idx), Some s -> Some(StepStageWarning(stage, idx, s))
            | _ -> None
        | [| "stage-committed"; stage |] -> Some(StageCommitted stage)
        | [| "build-finished"; status |] -> BuildStatus.ofWireString status |> Option.map BuildFinished
        | [| "script-digest"; d |] -> Some(ScriptDigest d)
        | [| "workspace-identity"; r; j |] -> Some(WorkspaceIdentity(r, j))
        | [| "build-identity"; id |] when id <> "" -> Some(BuildIdentity id)
        | [| "input-decision-voided"; stage; i; occurrence |] ->
            match System.Int32.TryParse i, System.Int32.TryParse occurrence with
            | (true, idx), (true, occ) -> Some(InputDecisionVoided(stage, idx, occ))
            | _ -> None
        | [| "step-reason"; stage; i; reason |] ->
            match System.Int32.TryParse i with
            | true, idx -> Some(StepReason(stage, idx, reason))
            | _ -> None
        | [| "retry-attempt"; stage; attempt |] ->
            match System.Int32.TryParse attempt with
            | true, n when n >= 2 -> Some(RetryAttemptStarted(stage, n))
            // attempt 1 never writes a marker, so one on disk is a corrupt or
            // hand-mangled line; refusing to decode stops the read where the
            // damage starts, per the journal's own contract
            | _ -> None
        | [| "input-prompt-cancellable"; stage; i; occurrence |] ->
            match System.Int32.TryParse i, System.Int32.TryParse occurrence with
            | (true, idx), (true, occ) -> Some(InputPromptCancellable(stage, idx, occ))
            | _ -> None
        | [| "input-answer-provisional"; stage; i; occurrence; verdict; who |] ->
            match System.Int32.TryParse i, System.Int32.TryParse occurrence, verdict with
            | (true, idx), (true, occ), "approved" -> Some(InputAnswerProvisional(stage, idx, occ, true, who))
            | (true, idx), (true, occ), "rejected" -> Some(InputAnswerProvisional(stage, idx, occ, false, who))
            | _ -> None
        | [| "input-decision"; stage; i; occurrence; verdict; who |] ->
            match System.Int32.TryParse i, System.Int32.TryParse occurrence, verdict with
            | (true, idx), (true, occ), "approved" -> Some(InputDecision(stage, idx, occ, true, who))
            | (true, idx), (true, occ), "rejected" -> Some(InputDecision(stage, idx, occ, false, who))
            // an unrecognised verdict is NOT a silent approval and not a silent
            // rejection: it fails to decode, which stops the read where the
            // damage starts rather than guessing a human's answer
            | _ -> None
        | _ -> None
