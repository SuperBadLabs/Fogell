namespace Fogell.Journal

open Fogell.Domain

/// What resume decided about one step.
type StepDisposition =
    /// Finished durably. MUST NOT run again — this is the exactly-once guarantee.
    | AlreadyFinished of BuildStatus
    /// Started, but no outcome was recorded. We do not know whether its effect
    /// happened. It is surfaced for reconciliation rather than silently re-run:
    /// re-running is at-least-once, and that is the semantics ADR 0003 rejects.
    | Interrupted
    /// Never reached. Safe to run.
    | NotStarted

/// The plan for continuing an interrupted attempt.
type ResumePlan =
    { /// Per (stage, index) decision.
      Steps: Map<string * int, StepDisposition>
      /// Stage-only status decoration produced by a durably finished step.
      /// Separate from Steps because a successful step can still leave its
      /// enclosing stage unstable without changing the build result.
      StageWarnings: Map<string * int, BuildStatus>
      /// Stages whose boundary was committed — everything in them is durable.
      CommittedStages: Set<string>
      /// Set when the build already reached a terminal state; resume is a no-op.
      Terminal: BuildStatus option
      /// The definition this journal belongs to, when recorded.
      ScriptDigest: string option
      /// The (workspace root, job name) the build ran in, when recorded.
      WorkspaceIdentity: (string * string) option
      /// FG-046b. This build's own identity, when its first attempt recorded
      /// one. Approval action ids derive from it rather than from any pathname.
      BuildIdentity: string option
      /// FG-046b. Answers already given to `input` prompts, per
      /// (stage, index, occurrence): (approved, submitter). Durable and
      /// independent of whether the step that asked ever finished. The
      /// occurrence separates prompts sharing one durability key — two `input`s
      /// in a `timeout` block are two gates, not one.
      InputDecisions: Map<string * int * int, bool * string>
      /// FG-046b. Prompts that could be CANCELLED while they waited — a deadline,
      /// or a failFast sibling. An answer to one of these is actionable only
      /// inside the attempt that read it, so it is never promoted and never
      /// adopted; an operator decides instead. See Record.InputPromptCancellable
      /// for why this cannot be fixed with another check.
      CancellablePrompts: Set<string * int * int>
      /// FG-046b. Prompts the journal holds ANY answer record for — actionable,
      /// provisional, or voided. The question it answers is narrow and physical:
      /// is this human's answer written down anywhere durable? An inbox
      /// `.decision` file whose key is absent here is the ONLY copy of it, and
      /// nothing may delete it.
      AnsweredKeys: Set<string * int * int>
      /// FG-046b. Steps a prior attempt started as `input`. Needed because a
      /// disposition alone does not say WHICH step was interrupted, and the
      /// re-run rule below applies to `input` and to nothing else.
      InputSteps: Set<string * int>
      /// FG-135. stage -> the LATEST retry attempt the journal shows started,
      /// absent meaning 1. A resumed retried stage continues from this attempt
      /// rather than replaying the loop from the top against dispositions that
      /// only describe the latest attempt.
      RetryAttempts: Map<string, int>
      /// Steps that started without finishing. Non-empty means a human or a
      /// policy must decide, because the engine genuinely does not know.
      NeedsReconciliation: (string * int) list }

module Resume =

    /// Build a resume plan from a journal.
    let plan (records: Record list) : ResumePlan =
        let steps =
            records
            |> List.fold
                (fun acc r ->
                    match r with
                    | StepStarted(stage, i, _) ->
                        // do not downgrade a finished step if records repeat
                        match Map.tryFind (stage, i) acc with
                        | Some(AlreadyFinished _) -> acc
                        | _ -> Map.add (stage, i) Interrupted acc
                    | StepFinished(stage, i, status) -> Map.add (stage, i) (AlreadyFinished status) acc
                    | StepStageWarning _ -> acc
                    // FG-135. A new retry attempt SUPERSEDES the stage's step records
                    // so far: they describe attempts that already failed, and reading
                    // a failed attempt's `step-finished` as durably-finished is what
                    // made a resume skip the step the next attempt needed. Dropping
                    // them here means the plan's dispositions are always the LATEST
                    // attempt's.
                    | RetryAttemptStarted(stage, _) -> acc |> Map.filter (fun (s, _) _ -> s <> stage)
                    // FG-114: a reason explains a disposition, it never IS one —
                    // and it survives retry markers as audit trail
                    | StepReason _ -> acc
                    | StageCommitted _
                    | BuildFinished _
                    | ScriptDigest _
                    | WorkspaceIdentity _
                    | BuildIdentity _
                    | InputDecision _
                    | InputDecisionVoided _
                    | InputAnswerProvisional _
                    | InputPromptCancellable _ -> acc)
                Map.empty

        let stageWarnings =
            records
            |> List.fold
                (fun acc r ->
                    match r with
                    | StepStageWarning(stage, i, status) ->
                        Map.change
                            (stage, i)
                            (fun prior ->
                                Some(
                                    prior
                                    |> Option.defaultValue BuildStatus.Success
                                    |> fun current -> BuildStatus.worstOf current status))
                            acc
                    | _ -> acc)
                Map.empty

        let inputSteps =
            records
            |> List.choose (function
                | StepStarted(stage, i, "input") -> Some(stage, i)
                | _ -> None)
            |> Set.ofList

        // last answer wins: a re-answered prompt (the first answer's attempt
        // died before the step could act on it) is still one human decision
        let inputDecisions =
            records
            |> List.fold
                (fun acc r ->
                    match r with
                    | InputDecision(stage, i, occ, approved, who) -> Map.add (stage, i, occ) (approved, who) acc
                    // a VOID removes it: the answer exists in the audit trail but
                    // is not actionable, and leaving it in this map is how a
                    // refused-as-late approval gets replayed by a resumed attempt
                    | InputDecisionVoided(stage, i, occ) -> Map.remove (stage, i, occ) acc
                    // a PROVISIONAL answer is deliberately absent from this map:
                    // it records that a human answered, not that the answer may
                    // be acted on. Only a promotion to InputDecision does that.
                    | _ -> acc)
                Map.empty

        { Steps = steps
          StageWarnings = stageWarnings
          RetryAttempts =
            records
            |> List.fold
                (fun acc r ->
                    match r with
                    // later markers overwrite: the LAST attempt started is the one
                    // a resume continues
                    | RetryAttemptStarted(stage, n) -> Map.add stage n acc
                    | _ -> acc)
                Map.empty
          AnsweredKeys =
            records
            |> List.choose (function
                | InputDecision(stage, i, occ, _, _) -> Some(stage, i, occ)
                | InputAnswerProvisional(stage, i, occ, _, _) -> Some(stage, i, occ)
                | InputDecisionVoided(stage, i, occ) -> Some(stage, i, occ)
                | _ -> None)
            |> Set.ofList
          CancellablePrompts =
            records
            |> List.choose (function
                | InputPromptCancellable(stage, i, occ) -> Some(stage, i, occ)
                | _ -> None)
            |> Set.ofList
          InputDecisions = inputDecisions
          InputSteps = inputSteps
          CommittedStages =
            records
            |> List.choose (function
                | StageCommitted s -> Some s
                | _ -> None)
            |> Set.ofList
          Terminal =
            records
            |> List.tryPick (function
                | BuildFinished s -> Some s
                | _ -> None)
          ScriptDigest =
            records
            |> List.tryPick (function
                | ScriptDigest d -> Some d
                | _ -> None)
          WorkspaceIdentity =
            records
            |> List.tryPick (function
                | WorkspaceIdentity(r, j) -> Some(r, j)
                | _ -> None)
          BuildIdentity =
            records
            |> List.tryPick (function
                | BuildIdentity id -> Some id
                | _ -> None)
          NeedsReconciliation =
            steps
            |> Map.toList
            |> List.choose (fun (k, v) ->
                match v with
                // the same rule as [inputAnswered], which cannot be called yet
                | Interrupted when
                    Set.contains k inputSteps
                    && (inputDecisions |> Map.exists (fun (s, i, _) _ -> (s, i) = k))
                    ->
                    None
                | Interrupted -> Some k
                | AlreadyFinished _
                | NotStarted -> None) }

    let dispositionOf (plan: ResumePlan) (stage: string) (index: int) =
        Map.tryFind (stage, index) plan.Steps |> Option.defaultValue NotStarted

    let stageWarningOf (plan: ResumePlan) (stage: string) (index: int) =
        Map.tryFind (stage, index) plan.StageWarnings

    let inputAnswered (plan: ResumePlan) (stage: string) (index: int) =
        Set.contains (stage, index) plan.InputSteps
        && plan.InputDecisions |> Map.exists (fun (s, i, _) _ -> s = stage && i = index)

    /// Should this step execute now?
    ///
    /// `false` for a durably finished step — that is exactly-once. `false` for an
    /// interrupted one too, because re-running it is precisely the at-least-once
    /// behaviour this design exists to avoid; it is reported instead. The single
    /// exception is [inputAnswered], stated above.
    let shouldExecute (plan: ResumePlan) (stage: string) (index: int) =
        match dispositionOf plan stage index with
        | AlreadyFinished _ -> false
        | Interrupted -> inputAnswered plan stage index
        | NotStarted -> true

    let isResumable (plan: ResumePlan) = plan.Terminal.IsNone
